/*
	release V1.0.6
		TBUSB_VERSION		"Ver.1.0.2"
			IDLE_2_XYP command-packet bmRequestType c0->40
	release V1.0.7 (not public release)
		TBCTL_VERSION		"Ver.1.0.4"
			added calibration point 3,4,5
		TBDRV_VERSION		"Ver.1.0.4"
			added calibration point 3,4,5
	release V1.0.8 
		TBCTL_VERSION		"Ver.1.0.5"
			added calibration point 9
			tbselector:change default left-top point
			tbselector:don't raise when doing calibration
		TBDRV_VERSION		"Ver.1.0.5"
			fixed bug:read max_x,y when usb read eeprom
	release V1.0.9 
		TBDRV_VERSION		"Ver.1.0.6"
			fixed bug:adjust data to 1024x768 saved eeprom data max_x,y
		TBCTL_VERSION		"Ver.1.0.6"
			tpin.c:delete 'extern' of errno
		TBUSB_VERSION		"Ver.1.0.3"
			delete "include malloc.h"
	release V1.1.0
		TBDRV_VERSION		"Ver.1.0.7"
			auto convert from calib-dat on change screen
	release V1.1.1
		TBDRV_VERSION		"Ver.1.0.8"
			auto convert from calib-dat-init-file on change screen
			timeout(=500msec) check when calib input
			fixed bug:make calib 4 area -->bug when adjust input-x,y
	release V1.1.2
		TBDRV_VERSION		"Ver.1.0.9"
			add to use DCA10 (share TSC10)
			change 500ms -> 300ms = timeout check when calib input
			change used function xf86STimestamp -> xf86getsecs 
			change for kernel 2.6 (fixed compile warning & error)
		TBCTL_VERSION		"Ver.1.0.7"
			add to use DCA10 (share TSC10)
			change for kernel 2.6 (fixed compile warning & error)
		TBUSB_VERSION		"Ver.1.0.4"
			change for kernel 2.6 (create new usb26 directory)
	release V1.1.3
		TBCTL_VERSION		"Ver.1.0.8"
			change tbctl's layout on VGA(640x480)
	release V1.1.4
		TBDRV_VERSION		"Ver.1.1.0"
			change protocol between tbtl to drvr,use pipe
		TBCTL_VERSION		"Ver.1.0.9"
			change protocol between tbtl to drvr,use pipe
	release V1.1.5
		TBCTL_VERSION		"Ver.1.1.0"
			fixed bug,display pen up/down when exec startx
		TBDRV_VERSION		"Ver.1.1.1"
			add re-initialize at usb re-connect for pnp
		TBUSB_VERSION		"Ver.1.0.5"
			add filter driver for pnp
		FILTERUSB_VERSION		"Ver.1.0.0"
			add filter driver for pnp (new create)
		TBCTL_VERSION		"Ver.1.1.0"
			add filter driver info. for version window
	release V1.1.6
		TBDRV_VERSION		"Ver.1.1.2"
			support for fc7's xwindow release1.3
		TBUSB_VERSION		"Ver.1.0.6"
			fixed bug,exclusive close & disconnect function 
*/
#define	RELEASE_VERSION		"Ver.1.1.6"
#define	TBCTL_VERSION		"Ver.1.1.0"	/* tbctl/<app> */
#define	TBDRV_VERSION		"Ver.1.1.2"	/* driver/dmc_drv.o */
#define	TBUSB_VERSION		"Ver.1.0.6"	/* usb26/ubbdmc.o or usb/usbdmc.o */
#define	FILTERUSB_VERSION	"Ver.1.0.0"	/* usb26/tpdmc.o or usb/tpdmc.o */
#define KER26 1
