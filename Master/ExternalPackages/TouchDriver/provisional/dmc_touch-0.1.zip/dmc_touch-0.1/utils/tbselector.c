/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
/*
 * EUC
 * tab=4
 */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <stdio.h>
#include <time.h>
//#include <curses.h>
#include "tb.h"

int main(int argc,char *argv[]);
void get_arg(int ac,char *av[],uRect *r);
void prhelp();

int wMain(uRect *first_r);
void wMain_draw_win(uWindowPtr win,int point);
void wMain_draw_mark(uWindowPtr win,int point);

void get_win_rect(uRect *r,uWindowPtr win);
int get_text_width(uWindowPtr win,char *s);
int get_char_height(uWindowPtr win,char c);

/***************************************************************************
 *	
 */
int main(int argc,char *argv[])
{
int a;
uRect r;
	setbuf(stdin,0);
	setbuf(stdout,0);
	if( argc >= 2 && argv[1][0] == '-' )
		prhelp();
	else
	{
		init_ulib();
		if( open_xinput_driver("DMC") != -1 )
		{
			get_arg(argc,argv,&r);
			a = wMain(&r);
		}
		term_ulib();
	}
	return(0);
}
void get_arg(int ac,char *av[],uRect *r)
{
int x,y,w,h;
	x = ac >= 2 ? atoi(av[1]) : 0;
	y = ac >= 3 ? atoi(av[2]) : 0;
	w = ac >= 4 ? atoi(av[3]) : 75+1;
	h = ac >= 5 ? atoi(av[4]) : 60+1;
	if( w <= 75 )
		w = 75+1;
	if( h <= 60 )
		h = 60+1;
#if 0
	if( ac <= 1 )
	{
		get_display_rect(r);
		x = r->width - w;
	}
#endif
	set_rect(r,x,y,w,h);
}
void prhelp()
{
	fprintf(stderr,"Syntax:tbselector {<Option>} {<x> <y> <size_x> <size_y>} \n");
	fprintf(stderr,"Function: %s DMC-Touch-Panel Button Selector on X-Window\n",ProductName);
	fprintf(stderr,"	<x>  		window point x\n");
	fprintf(stderr,"	<y>  		window point y\n");
	fprintf(stderr,"	<size_x>	window size x\n");
	fprintf(stderr,"	<size_y>	window size y\n");
	fprintf(stderr,"Option:\n");
	fprintf(stderr,"    -?     help\n");
	exit(0);
}

/***************************************************************************
 *
 */
int wMain(uRect *first_r)
{
//
#define	CTL_TITLE	0
#define	CTL_CLOSE	1
#define	CTL_LEFT	2
#define	CTL_MID		3
#define	CTL_RIGHT	4
#define	MAX_CTL		5
uControlPtr ctl[MAX_CTL];
#define	GroupButton	1
//
uWindowPtr win;
uRect r,tbar;
uColor fgcolor,bgcolor;
XEvent ev;
int end,i,x,y,px,py,w,max_x,max_y;
int now,on_sav,win_move;
time_t start;
char s[100];
	get_display_rect(&r);
	max_x = r.x + r.width;
	max_y = r.y + r.height;
	fgcolor = BlackPixel(gDisp,0);
	bgcolor = get_color(0xe000,0xe000,0xe000);
	sprintf(s,"%s Selector",ProductName);
	px = -1;
	py = -1;
	w = first_r->width;
	set_rect(&tbar,1,1,w-20-1,20-2);
	win = new_window(first_r,s,fgcolor,bgcolor,true);
	ctl[CTL_TITLE] = new_control(win,PT_BUTTON,"SELECTOR",&tbar,false,0);
	set_rect(&tbar,w-20+2,1,20-4,20-2);
	ctl[CTL_CLOSE] = new_control(win,PT_BUTTON,"X",&tbar,false,0);
	w = first_r->width / 3;
	set_rect(&r,(w*0),20+1,w-1,first_r->height-20-3);
	ctl[CTL_LEFT] = new_control(win,PT_GBUTTON,"L",&r,false,GroupButton);
	set_rect(&r,(w*1),20+1,w-1,first_r->height-20-3);
	ctl[CTL_MID]  = new_control(win,PT_GBUTTON,"M",&r,false,GroupButton);
	set_rect(&r,(w*2),20+1,w-1,first_r->height-20-3);
	ctl[CTL_RIGHT] = new_control(win,PT_GBUTTON,"R",&r,false,GroupButton);
	XSelectInput(gDisp,win->win,NormalMask);
	now = 0;
	set_radio_group_state(ctl,now+2,MAX_CTL);
	wMain_draw_win(win,now);
	win_move = false;
	start = time(NULL);
	for( end=false ; !end ; )
	{
		if( difftime(time(NULL),start) >= 1 )
		{
			if( !find_ps("tbcalib") )
				XRaiseWindow(gDisp,win->win);
			start = time(NULL);
		}
		if( now != 0 && (i = is_selector_on()) == 0 )
		{
			now = 0;
			set_radio_group_state(ctl,now+2,MAX_CTL);
			wMain_draw_win(win,now);
			draw_control(ctl,MAX_CTL);
			usleep(100*1000);
		}	
		if( !XCheckWindowEvent(gDisp,win->win,NormalMask,&ev) )
		{
			if( !XCheckTypedEvent(gDisp,ClientMessage,&ev) )
				continue;
		}
		//XNextEvent(gDisp,&ev);
		switch( ev.type )
		{
		case	ButtonPress:
			i = ctl_mouse_on(ctl,MAX_CTL,&ev);
			on_sav = i;
			switch( i )
			{
			case	CTL_TITLE:
				get_win_rect(&r,win);
				px = ev.xbutton.x + r.x;
				py = ev.xbutton.y + r.y;
				win_move = true;
				break;
			default:
				break;
			}
			break;
		case	ButtonRelease:
			win_move = false;
			i = ctl_mouse_off(ctl,MAX_CTL,&ev);
			switch( i )
			{
			case	CTL_TITLE:
				break;
			case	CTL_CLOSE:
				end = true;
				break;
			case	-1:
			default:
				i = find_radio_group_on(ctl,MAX_CTL,GroupButton);
				if( on_sav == i )
				{
					now = i - 2;
					select_button(i-2);
				}
				break;
			}
			break;
		case	MotionNotify:
			if( win_move )
			{
				get_win_rect(&r,win);
				x = ev.xmotion.x + r.x;
				y = ev.xmotion.y + r.y;
				i = r.x+(x-px);
				if( i < 0 )
					break;
				i += r.width;
				if( i > max_x )
					break;
				i =	r.y+(y-py);
				if( i < 0 )
					break;
				i += r.height;
				if( i > max_y )
					break;
				XMoveWindow(gDisp,win->win,r.x+(x-px),r.y+(y-py));
				px = x;
				py = y;
			}
			break;
		case	LeaveNotify:
			break;
		case	Expose:	/* = window draw */
			wMain_draw_win(win,now);
			draw_control(ctl,MAX_CTL);
			break;
		case	ClientMessage:
			if( ev.xclient.message_type == win->a1 && ev.xclient.data.l[0] == win->a2 )
				end = true;
			break;
		case	DestroyNotify:
			end = true;
			break;
		}
	}
	destroy_window(win);
	return( 0 );
}
void wMain_draw_win(uWindowPtr win,int now)
{
#if 0
uRect r;
int x,y,w;
char s[100];
	//
	get_win_rect(&r,win);
	r.x = 0;
	r.y = 0;
	erase_rect(win,&r);
	strcpy(s,(now==0?"Left":"Right"));
	w = get_text_width(win,s);
	x = (r.width/2) - (w/2);
	y = ((r.height-20)/2) + 20 + 5;
	//XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));
#endif
}

