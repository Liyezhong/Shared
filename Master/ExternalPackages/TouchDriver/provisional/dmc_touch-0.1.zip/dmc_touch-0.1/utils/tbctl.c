/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
/*
 * EUC
 * tab=4
 */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <stdio.h>
#include <sys/wait.h>
#include "tb.h"
#include "../driver/cmd.h"
#include "../vers.h"

#define	CALIB_SET_234569	0

int main(int argc,char *argv[]);
void prhelp();
void domain();

int run_exec(int cmd);
#define	CMD_TBCALIB		0
#define	CMD_TBTEST		1
#define	CMD_SELECTOR	2

int wVer();
void wVer_draw_win(uWindowPtr win,int y);

int pid;
int fork_cur_dir = false;

#define	S_RATE_GROUP		1
int srate = S_RATE_1st;
char *sratetb[] = { "30 p/s","50 p/s","80 p/s","100 p/s","130 p/s","150 p/s",NULL };
#define	B_DOWN_BELL		(1<<B_BEEP_UP_ON)
#define	B_UP_BELL		(1<<B_BEEP_DOWN_ON)
int touchbell = B_DOWN_BELL|B_UP_BELL;
int bellcount = 2;
char *belltb[] = { "Touch Down Beep on","Touch Up Beep on",NULL };
#define	CALIB_POINT_GROUP	2
int calib_point_num = 2;
#if CALIB_SET_234569
char *calibtb[] = { "2 points","3 points","4 points","5 points","6 points","9 points",NULL };
#else
char *calibtb[] = { "2 points","3 points","4 points","5 points","9 points",NULL };
#endif
#define	CALIB_TIMOUT_GROUP	3
int calib_timeout = 10;
char *totb[] = { "10 sec","20 sec","60 sec",NULL };

int main(int argc,char *argv[])
{
	setbuf(stdin,0);
	setbuf(stdout,0);
	if( argc >= 2 && argv[1][0] == '-' )
	{
		switch( argv[1][1] )
		{
		case	'c':
			fork_cur_dir = true;
			break;
		case	'?':
		default:
			prhelp();
			exit(0);
		}
	}
	domain();
	return(0);
}
void prhelp()
{
	fprintf(stderr,"Syntax:tbctl {<Option>} \n");
	fprintf(stderr,"Function: %s DMC touch-panel Control Main on X-Window\n",ProductName);
	fprintf(stderr,"Option:\n");
	fprintf(stderr,"    -?     help\n");
	exit(0);
}

void domain()
{
uWindowPtr win;
uColor fgcolor,bgcolor;
int btnum[10];
#define	BTNUM_VER		0
#define	BTNUM_APPLY		1
#define	BTNUM_TEST		2
#define	BTNUM_SELECTOR	3
#define	BTNUM_CALIB		4
uControlPtr ctl[50];
int ctlnum;
int srate_base,bell_base;
XEvent ev;
Cursor cs;
uRect r;
int end,i,x,y,w,h,ww,x1,y1,y2,base;
KeySym key;
char s[100];
int scr640flg,bx1,by1;
	init_ulib();
	open_xinput_driver("DMC");
	touchbell = get_beep();
	srate = get_samp_rate();
	calib_point_num = get_calib_point_num();
	get_display_rect(&r);
	scr640flg = r.width < 800 ? 1 : 0;
	if( scr640flg )
	{
		w = 600;
		h = 270;
	}
	else
	{
		w = 330;
	#ifdef _3MEX2
		h = 370;
	#else
	#if	CALIB_SET_234569
		h = 490;
	#else
		h = 465;
	#endif
	#endif
	}
	x = (r.width/2) - (w/2);
	y = (r.height/4) - (h/2);
	if( y <= 10 )
		y = 50;
	set_rect(&r,x,y,w,h);
	fgcolor = BlackPixel(gDisp,0);
	bgcolor = get_color(0xe000,0xe000,0xe000);
	sprintf(s,"%s Control Main",ProductName);
	win = new_window(&r,s,fgcolor,bgcolor,false);
	// +----------------------------------------------------+
	// |                                          Ver.1.0.1 |
	// | < Sampling Rate >      < Sound >                   | <-- y1
	// |      30 p/s         Touch Down Beep on             |
	// |      50 p/s         Touch Up Beep on               |
	// |      80 p/s                                        |
	// |     100 p/s                                        |
	// |     130 p/s                                        |
	// |     150 p/s                                        |
	// | +---------------------+ +------------------------+ |
	// | |       Apply         | |       Test...          | |
	// | +---------------------+ +------------------------+ |
	// | +---------------------+                            |
	// | |    Run Selector     |                            |
	// | +---------------------+                            |
	// | < Calibration Points > < Calibration Time Out >    | <-- y1
	// |     2 points              10 sec                   |
	// |                           20 sec                   |
	// |                           60 sec                   |
	// | +------------------------------------------------+ |
	// | |               Calibration...                   | |
	// | +------------------------------------------------+ |
	// +----------------------------------------------------+
	//   |
	//   x1
	XMoveWindow(gDisp,win->win,x,y);
	x1 = x = (w/2) - ((w-10)/2);
	y = 5;
	w -= 10;
	h = 25;
	ctlnum = 0;
	strcpy(s,RELEASE_VERSION);
	w = get_text_width(win,s);
	set_rect(&r,r.width-w-20,y,w+10,h);
	btnum[BTNUM_VER] = ctlnum;
	ctl[ctlnum++] = new_control(win,PT_BUTTON,s,&r,STATE_OFF,0);
	y += 20;
	y1 = y;
#ifdef _3MEX2
	y2 = 0;
#else
	strcpy(s,"< Sampling Rate >");
	w = get_text_width(win,s);
	set_rect(&r,x,y,w,h);
	ctl[ctlnum++] = new_control(win,PT_STEXT,s,&r,STATE_LEFT,0);
	ww = get_text_width(win,sratetb[0]) + 20;
	x = x + (w/2) - (ww/2);
	for( i=0,srate_base=base=ctlnum ; sratetb[i] ; i++ )
	{
		y += (20 + 5);
		set_rect(&r,x,y,w,h);
		ctl[ctlnum++] = new_control(win,PT_RADIO,sratetb[i],&r,STATE_OFF,S_RATE_GROUP);
		if( srate == i )
			ctl[base+i]->state = STATE_ON;
	}
	y += (20 + 5);
	y2 = y;
	x = x1 + w + 10;
	y = y1;
#endif
	strcpy(s,"      < Sound >      ");
	w = get_text_width(win,s);
	set_rect(&r,x,y,w,h);
	ctl[ctlnum++] = new_control(win,PT_STEXT,s,&r,STATE_LEFT,0);
	ww = get_text_width(win,belltb[0]) + 20;
	x = x + (w/2) - (ww/2);
	for( i=0,bell_base=base=ctlnum ; belltb[i] ; i++ )
	{
		y += (20 + 5);
		set_rect(&r,x,y,w,h);
		ctl[ctlnum++] = new_control(win,PT_CKBOX,belltb[i],&r,STATE_OFF,0);
		if( touchbell & (1<<(bellcount-i-1)) )
			ctl[base+i]->state = STATE_ON;
	}
	y += (20 + 5);
	if( y2 < y )
		y2 = y;
	get_win_rect(&r,win);
	x = x1;
	y = y2;
	if( scr640flg )
		w = (r.width/4) - 10;
	else
		w = (r.width/2) - 10;
	by1 = y;
	h = 25;
	set_rect(&r,x,y,w,h);
	btnum[BTNUM_APPLY] = ctlnum;
	ctl[ctlnum++] = new_control(win,PT_BUTTON,"Apply",&r,STATE_OFF,0);
	x += w + 10;
	if( scr640flg )
		set_rect(&r,x,y,w-20,h);
	else
		set_rect(&r,x,y,w,h);
	btnum[BTNUM_TEST] = ctlnum;
	ctl[ctlnum++] = new_control(win,PT_BUTTON,"Test...",&r,STATE_OFF,0);
	bx1 = x + w + 5;
	x = x1;
	y += 25;
	y += 5;
	set_rect(&r,x,y,w,h);
	btnum[BTNUM_SELECTOR] = ctlnum;
	ctl[ctlnum++] = new_control(win,PT_BUTTON,"Run Selector",&r,STATE_OFF,0);
	x = x1;
	y += (25+5);
	y += 10;
	get_win_rect(&r,win);
	w = r.width - 10;
	set_rect(&r,x,y,w,0);
	if( scr640flg )
	{
		x1 = x = bx1;
		y = y1;
		strcpy(s,"< Calibration Points >");
		w = get_text_width(win,s);
		set_rect(&r,x,y,w,h);
		ctl[ctlnum++] = new_control(win,PT_STEXT,s,&r,STATE_LEFT,0);
		ww = get_text_width(win,calibtb[0]) + 20;
		x = x + (w/2) - (ww/2);
		for( i=0,base=ctlnum ; calibtb[i] ; i++ )
		{
			y += (20 + 5);
			set_rect(&r,x,y,w,h);
			ctl[ctlnum++] = new_control(win,PT_RADIO,calibtb[i],&r,STATE_OFF,CALIB_POINT_GROUP);
			if( calib_point_num == atoi(calibtb[i]) )
				ctl[base+i]->state = STATE_ON;
		}
		y2 = y;
		x = x1 + w + 10;
		y = y1;
		strcpy(s,"< Calibration Time Out >");
		w = get_text_width(win,s);
		set_rect(&r,x,y,w,h);
		ctl[ctlnum++] = new_control(win,PT_STEXT,s,&r,STATE_LEFT,0);
		ww = get_text_width(win,totb[0]) + 20;
		x = x + (w/2) - (ww/2);
		for( i=0,base=ctlnum ; totb[i] ; i++ )
		{
			y += (20 + 5);
			set_rect(&r,x,y,w,h);
			ctl[ctlnum++] = new_control(win,PT_RADIO,totb[i],&r,STATE_OFF,CALIB_TIMOUT_GROUP);
			if( calib_timeout == atoi(totb[i]) )
				ctl[base+i]->state = STATE_ON;
		}
		y = y2 >= y ? y2 : y;
		x = x1;
		y = by1;
		get_win_rect(&r,win);
		w = r.width - bx1 - 10;
		set_rect(&r,x,y,w,h);
		btnum[BTNUM_CALIB] = ctlnum;
		ctl[ctlnum++] = new_control(win,PT_BUTTON,"Calibration...",&r,STATE_OFF,0);
	}
	else
	{
		ctl[ctlnum++] = new_control(win,PT_LINE,"line",&r,STATE_OFF,0);
		y += 10;
		y1 = y;
		strcpy(s,"< Calibration Points >");
		w = get_text_width(win,s);
		set_rect(&r,x,y,w,h);
		ctl[ctlnum++] = new_control(win,PT_STEXT,s,&r,STATE_LEFT,0);
		ww = get_text_width(win,calibtb[0]) + 20;
		x = x + (w/2) - (ww/2);
		for( i=0,base=ctlnum ; calibtb[i] ; i++ )
		{
			y += (20 + 5);
			set_rect(&r,x,y,w,h);
			ctl[ctlnum++] = new_control(win,PT_RADIO,calibtb[i],&r,STATE_OFF,CALIB_POINT_GROUP);
			if( calib_point_num == atoi(calibtb[i]) )
				ctl[base+i]->state = STATE_ON;
		}
		y2 = y;
		x = x1 + w + 10;
		y = y1;
		strcpy(s,"< Calibration Time Out >");
		w = get_text_width(win,s);
		set_rect(&r,x,y,w,h);
		ctl[ctlnum++] = new_control(win,PT_STEXT,s,&r,STATE_LEFT,0);
		ww = get_text_width(win,totb[0]) + 20;
		x = x + (w/2) - (ww/2);
		for( i=0,base=ctlnum ; totb[i] ; i++ )
		{
			y += (20 + 5);
			set_rect(&r,x,y,w,h);
			ctl[ctlnum++] = new_control(win,PT_RADIO,totb[i],&r,STATE_OFF,CALIB_TIMOUT_GROUP);
			if( calib_timeout == atoi(totb[i]) )
				ctl[base+i]->state = STATE_ON;
		}
		y = y2 >= y ? y2 : y;
		x = x1;
		y += (25 + 5);
		get_win_rect(&r,win);
		w = r.width - 10;
		set_rect(&r,x,y,w,h);
		btnum[BTNUM_CALIB] = ctlnum;
		ctl[ctlnum++] = new_control(win,PT_BUTTON,"Calibration...",&r,STATE_OFF,0);
	}
	ctl[ctlnum] = NULL;
	if( ctlnum >= (sizeof(ctl)/sizeof(uControlPtr)) )
	{
		printf("BUFFER ERROR\n");
		exit(0);
	}
	XSelectInput(gDisp,win->win,NormalMask);
	draw_control(ctl,ctlnum);
	pid = -1;
	for( end=false ; !end ; )
	{
		if( pid != -1 )
		{
			if( waitpid(pid,NULL,WNOHANG) == pid )
				pid = -1;;
		}
		XNextEvent(gDisp,&ev);
		switch( ev.type )
		{
		case	KeyPress:
			if( XLookupString(&ev.xkey,s,10,&key,NULL) >= 1 )
			{
				switch( s[0] )
				{
					case 'e': end = true;		break;
				}
			}
			break;
		case	ButtonPress:
			ctl_mouse_on(ctl,ctlnum,&ev);
			break;
		case	ButtonRelease:
			i = ctl_mouse_off(ctl,ctlnum,&ev);
			if( i == btnum[BTNUM_VER] )		// ver button
			{
				wVer();
				draw_control(ctl,ctlnum);
			}
			else if( i == btnum[BTNUM_APPLY] )		// apply button
			{
				cs = XCreateFontCursor(gDisp,XC_clock);
				XDefineCursor(gDisp,win->win,cs);
				XFlush(gDisp);
			#ifdef _3MEX2
				y2 = 0;
			#else
				i = find_radio_group_on(ctl,ctlnum,S_RATE_GROUP);
				// ++++++++++++ set sample rate ++++++++++++++++
				y2 = i - srate_base;
				if( set_samp_rate(y2) == -1 )
				{
					XUndefineCursor(gDisp,win->win);
					msgbox("Error","set error",MB_OK);
					break;
				}
				srate = y2;
			#endif
				// ++++++++++++ set beep ++++++++++++++++
				if( ctl[bell_base+0]->state == STATE_ON )
					y2 |= B_DOWN_BELL;
				else
					y2 &= (~B_DOWN_BELL);
				if( ctl[bell_base+1]->state == STATE_ON )
					y2 |= B_UP_BELL;
				else
					y2 &= (~B_UP_BELL);
				set_beep(1,(y2&B_DOWN_BELL?1:0));
				set_beep(0,(y2&B_UP_BELL?1:0));
				save_exec();
				touchbell = y2;
			#ifndef _3MEX2
				// ++++++++++++ do reset ++++++++++++++++
				sleep(2);
				reset_tb();
			#endif
				XUndefineCursor(gDisp,win->win);
			}
			else if( i == btnum[BTNUM_TEST] )	// test button
			{
				pid = run_exec(CMD_TBTEST);
			}
			else if( i == btnum[BTNUM_SELECTOR] )	// selector button
			{
				pid = run_exec(CMD_SELECTOR);
			}
			else if( i == btnum[BTNUM_CALIB] )	// calib button
			{
				i = find_radio_group_on(ctl,ctlnum,CALIB_POINT_GROUP);
				calib_point_num = atoi(ctl[i]->s);
				i = find_radio_group_on(ctl,ctlnum,CALIB_TIMOUT_GROUP);
				calib_timeout = atoi(ctl[i]->s);
				pid = run_exec(CMD_TBCALIB);
			}
			break;
		case	MotionNotify:
		case	LeaveNotify:
			break;
		case	Expose:	/* = window draw */
			draw_control(ctl,ctlnum);
			break;
		case	ClientMessage:
			if( ev.xclient.message_type == win->a1 && ev.xclient.data.l[0] == win->a2 )
				end = true;
			break;
		case	DestroyNotify:
			end = true;
			break;
		}
	}
	destroy_window(win);
	term_ulib();
}
int run_exec(int cmd)
{
char s[100],path[100];
	path[0] = 0;
	if( fork_cur_dir )
		strcpy(path,"./");
#if 1
	switch( cmd )
	{
	case	CMD_TBCALIB:
		sprintf(s,"%stbcalib %d %d &",path,calib_point_num,calib_timeout);
		break;
	case	CMD_TBTEST:
		sprintf(s,"%stbtest &",path);
		break;
	case	CMD_SELECTOR:
		if( find_ps("tbselector") )
		{
			msgbox("Warning!!","Don't run at same time",MB_OK);
			return(-1);
		}
		sprintf(s,"%stbselector &",path);
		break;
	default:
		return(-1);
	}
	system(s);
	return(-1);
#else
char *av[10];
	switch( cmd )
	{
	case	CMD_TBCALIB:
		sprintf(&s[0],"%stbcalib",path);
		av[0] = &s[0];
		sprintf(&s[15],"%d",calib_point_num);
		av[1] = &s[15];
		sprintf(&s[30],"%d",calib_timeout);
		av[2] = &s[30];
		av[3] = NULL;
		break;
	case	CMD_TBTEST:
		sprintf(s,"%stbtest",path);
		av[0] = s;
		av[1] = NULL;
		break;
	case	CMD_SELECTOR:
		if( find_ps("tbselector") )
		{
			msgbox("Warning!!","Don't run at same time",MB_OK);
			return(-1);
		}
		sprintf(s,"%stbselector",path);
		av[0] = s;
		av[1] = NULL;
		break;
	default:
		return(-1);
	}
	if( (pid == fork()) == -1 )
		return(-1);
	if( pid == 0 )
	{
		execv(av[0],av);
		exit(1);
	}
	printf("fork [%s]\n",av[0]);
	return(pid);
#endif
}


/***************************************************************************
 *
 */
int wVer()
{
uWindowPtr win;
uControlPtr ctl[3];
XEvent ev;
uRect r;
uColor fgcolor,bgcolor;
int x,y,w,h,msg_y;
int end,i,res;
Cursor cs;
char title[100];
	get_display_rect(&r);
	fgcolor = BlackPixel(gDisp,0);
	//bgcolor = WhitePixel(gDisp,0);
	bgcolor = get_color(0xe000,0xe000,0xe000);
	w = r.width;
	h = r.height;
	x = r.x + (w / 2) - 150;
	w = 300;
	y = r.y + (h / 5);
	h = 110;
	msg_y = 20;
	set_rect(&r,x,y,w,h);
	sprintf(title,"%s Version Information",ProductName);
	win = new_window(&r,title,fgcolor,bgcolor,false);
	XFlush(gDisp);
	XMoveWindow(gDisp,win->win,x,y);
	XSelectInput(gDisp,win->win,NormalMask);
	wVer_draw_win(win,msg_y);
	XFlush(gDisp);
	for( res=0,end=false ; !end ; )
	{
		XNextEvent(gDisp,&ev);
		switch( ev.type )
		{
		case	ButtonPress:
			break;
		case	ButtonRelease:
			end = true;
			break;
		case	Expose:	/* = window draw */
			wVer_draw_win(win,msg_y);
			break;
		case	ClientMessage:
			if( ev.xclient.message_type == win->a1 && ev.xclient.data.l[0] == win->a2 )
				end = true;
			break;
		case	DestroyNotify:
			end = true;
			break;
		}
	}
	destroy_window(win);
	XFlush(gDisp);
	return(res);
}
void wVer_draw_win(uWindowPtr win,int y)
{
uRect r;
int i,x,w;
char s[100];
	get_win_rect(&r,win);
	sprintf(s,"relase       :      %s",RELEASE_VERSION);
	w = get_text_width(win,s);
	x = r.x + (r.width/2) - (w/2);
	XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));
	y += 20;
	sprintf(s,"tbctl        :      %s",TBCTL_VERSION);
	XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));
	y += 20;
	sprintf(s,"dmc_drv      :      %s",TBDRV_VERSION);
	XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));
#ifndef _3MEX2
	y += 20;
	sprintf(s,"usbdmc       :      %s",TBUSB_VERSION);
	XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));
	y += 20;
	sprintf(s,"tpdmc        :      %s",FILTERUSB_VERSION);
	XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));
#endif
}

