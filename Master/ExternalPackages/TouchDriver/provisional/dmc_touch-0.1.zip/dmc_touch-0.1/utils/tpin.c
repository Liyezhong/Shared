/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
//#define _3MEX2	1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <termio.h>
#include <unistd.h>

int main(int ac,char *av[]);
void read_pendown_data(int fd);
int aread(int path,char *p,int len);
void setup_sio(int fd);
int kbhit();
int io_rdy(int path);

#ifndef true
#define	true	1
#define	false	0
#endif

u_char reset[]		 = { 0x55 };
u_char specify[]	 = { 0x05,0x41 };
u_char to_idle_xyp[] = { 0x31 };
u_char to_xyp_idle[] = { 0x02 };
u_char status[]		 = { 0x15 };
u_char rdeeprom[]	 = { 0x1d };

int main(int ac,char *av[])
{
int fd,rcnt,xyp_mode;
char *dev;
u_char c;
	setbuf(stdin,0);
	if( ac >= 2 )
		dev = av[1];
	else
		dev = "/dev/ttyS0";
	if( (fd = open(dev,O_RDWR|O_NOCTTY,S_IREAD|S_IWRITE)) == -1 )
		exit(0);
	setup_sio(fd);
	printf(">> touch-panel test prog. open [%s]\n",dev);
	xyp_mode = 1;
	while(1)
	{
		if( kbhit() )
		{
			switch( input_cmd() )
			{
			case	1:
				//close(fd);
				//if( (fd = open(dev,S_IREAD|S_IWRITE)) == -1 )
				//	exit(0);
				//sleep(1);
				awrite(fd,reset,sizeof(reset));				xyp_mode = 0;	break;
			case	2:	awrite(fd,specify,sizeof(specify));							break;
			case	3:	awrite(fd,to_idle_xyp,sizeof(to_idle_xyp));	xyp_mode = 1;	break;
			case	4:	awrite(fd,to_xyp_idle,sizeof(to_xyp_idle));	xyp_mode = 0;	break;
			case	10:	awrite(fd,status,sizeof(status));							break;
			case	11:	awrite(fd,rdeeprom,sizeof(rdeeprom));						break;
			}
			continue;
		}
		if( !io_rdy(fd) )
			continue;
		if( (rcnt = aread(fd,(char *)&c,1)) < 0 )
			break;
		if( rcnt == 0 )
			continue;
		if( xyp_mode )
		{
			switch( c )
			{
			#if _3MEX2
				case	0xd8:
					printf("PenDown:");
					read_pendown_data(fd);
					break;
				case	0x98:
					printf("PenUp  :");
					read_pendown_data(fd);
					break;
			#else
				case	0x11:
					printf("PenDown:");
					read_pendown_data(fd);
					break;
				case	0x10:
					printf("PenUp\n");
					break;
			#endif
				default:
					printf("in = $%02X\n",c);
					break;
			}
		}
		else
			printf("in = $%02X\n",c);
	}
	return(0);
}
int input_cmd()
{
int i;
char c,s[100];
	for( i=0 ; kbhit() ; )
		read(fileno(stdin),&c,1);
	printf("*** command ***\n");
	printf("  1:reset         2:specify\n");
	printf("  3:goto XYP      4:goto IDLE from XYP\n");
	printf(" 10:read status  11:read eeprom\n");
	printf("input = ");
	s[0] = 0;
	for( i=0 ; i < 50 ; )
	{
		if( read(fileno(stdin),&c,1) < 0 )
			return(0);
		if( c == 0x0a && i != 0 )
			break;
		if( c < '0' && c > '9' )
			continue;
		s[i++] = c;
		s[i] = 0;
	}
	printf(".....[%s] %d\n",s,atoi(s));
	return(atoi(s));
}
void read_pendown_data(int fd)
{
int i,k,x,y;
u_char c,buf[100];
	for( i=0 ; i < 4 ; i++ )
	{
		if( read(fd,&c,1) < 0 )
			break;
		buf[i] = c;
	}
	if( i >= 4 )
	{
		#if _3MEX2
			x = (buf[1] << 7) | buf[0];
			y = (buf[3] << 7) | buf[2];
		#else
			x = (buf[0] << 8) | buf[1];
			y = (buf[2] << 8) | buf[3];
		#endif
		printf("(x,y)=(%3d,%3d)=($%04X,$%04x) : $%02x $%02x $%02x $%02x\n"
								,x,y,x,y,buf[0],buf[1],buf[2],buf[3]);
	}
	else
	{
		for( k=0 ; k < i ; k++ )
			printf("in = $%02X \n",buf[k]);
	}
}
int awrite(int path,char *p,int len)
{
int res,i;
	printf("OUT len=%d ",len);
	for( i=0 ; i < len ; i++ )
		printf("$%x ",p[i]);
	printf("\n");
	res = write(path,p,len);
	printf("write %d\n",res);
	return(res);
}
int aread(int path,char *p,int len)
{
int i;
time_t start_time;
	time(&start_time);
	for( i=0 ; i < len ; )
	{
		if( difftime(time(NULL),start_time) >= 5 )
			break;
		if( !io_rdy(path) )
			continue;
		read(path,&p[i],1);
		i++;
	}
	return(i);
}
void setup_sio(int fd)
{
struct termios  tio, tin;
	tcgetattr( fd, &tio );
	tin = tio;
	tin.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP
					|INLCR|IGNCR|ICRNL|IXON|IXOFF);
	tin.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG|IEXTEN);
	tin.c_oflag &= ~(OPOST|ONLCR|OCRNL);
	/* ....9600bps/8bit/1stop/non-parity/HW-Flow */
	tin.c_cflag &= ~(CSIZE|CSTOPB|PARENB|PARODD);
	tin.c_cflag |= (CS8|CLOCAL);
	cfsetispeed(&tin,9600);
	cfsetospeed(&tin,9600);
	fprintf(stderr,"path=%d raw mode\n",fd);
	tcsetattr( fd, TCSANOW, &tin );
}
int kbhit()
{
	return( io_rdy(fileno(stdin)) );
}
int io_rdy(int path)
{
fd_set rfds;
struct timeval tv;
int ret;
	/* stdin (fd 0) ��ƻ뤷�����Ϥ����ä�����ɽ�����롣*/
	FD_ZERO(&rfds);
	FD_SET(path, &rfds);
	tv.tv_sec = 0;
	tv.tv_usec = 10*1000;
	ret = select(path+1, &rfds, NULL, NULL, &tv);
	return( ret <= 0 ? false : true );
}


