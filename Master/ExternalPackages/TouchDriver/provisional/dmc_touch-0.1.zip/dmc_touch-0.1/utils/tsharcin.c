/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
//#define _3MEX2	1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <termio.h>
#include <unistd.h>
#include <linux/input.h>

int main(int ac,char *av[]);
int io_rdy(int path);

#ifndef true
#define	true	1
#define	false	0
#endif

int main(int ac,char *av[])
{
int i,k,fd,rcnt,xyp_mode;
char *dev;
u_char c,s[100];
struct input_event *ip;
	setbuf(stdout,0);
	if( ac >= 2 )
		dev = av[1];
	else
		dev = "/dev/input/event_tsharc";
	if( (fd = open(dev,O_RDONLY)) == -1 )
		exit(0);
	printf(">> touch-panel test prog. open [%s]\n",dev);
	xyp_mode = ac >= 3 ? 0 : 1;
	for( i=0 ; ; )
	{
		if( !io_rdy(fd) )
		{
			//printf(".");
			continue;
		}
		if( (rcnt = read(fd,(char *)s,16)) <= 0 )
			continue;
		ip = (struct input_event *)s;
		if( xyp_mode )
		{
			switch( ip->type )
			{
			case	EV_ABS:
				printf("(%d):EV_ABS %s %d\n"
					,i,(ip->code?"ABS_Y":"ABS_X"),ip->value);
				break;
			case	EV_KEY:
				if( ip->code == BTN_MOUSE )
					printf("(%d):EV_KEY BTN_MOUSE %s\n"
									,i,(ip->value?"ON":"OFF"));
				else
					printf("(%d):EV_KEY $%04x  %d\n",i,ip->code,ip->value);
				break;
			case	EV_SYN:
				printf("(%d):EV_SYN $%04x %d\n",i,ip->code,ip->value);
				break;
			default:
				printf("(%d):type=$%04x code=$%04x value=$%08x\n"
					,i,ip->type,ip->code,ip->value);
				break;
			}
			i++;
		}
		else
		{
			printf("(%5d):",i);
			for( k=0 ; k < rcnt ; k++ )
				printf("%02x ",s[k]);
			printf("\n");
			i++;
		}
	}
	return(0);
}
int io_rdy(int path)
{
fd_set rfds;
struct timeval tv;
int ret;
	/* stdin (fd 0) ��ƻ뤷�����Ϥ����ä�����ɽ�����롣*/
	FD_ZERO(&rfds);
	FD_SET(path, &rfds);
	tv.tv_sec = 0;
	tv.tv_usec = 10*1000;
	ret = select(path+1, &rfds, NULL, NULL, &tv);
	return( ret <= 0 ? false : true );
}


