/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
/*
 * EUC
 * tab=4
 */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <stdio.h>
#include <time.h>
//#include <curses.h>
#include "tb.h"

BOOL set_calibration_dat();
int make_adjust_xy_point(uRect adj[],uRect mark[],int point_max);
void caldif(uRect *d,uRect *a,uRect *b);
int main(int argc,char *argv[]);
void prhelp();

int wMain();
void wMain_draw_win(uWindowPtr win,int point);
void wMain_draw_mark(uWindowPtr win,int point);

int wEndWait(int err);
void wEndWait_draw_win(uWindowPtr win,int y,int err);

void get_win_rect(uRect *r,uWindowPtr win);
int get_text_width(uWindowPtr win,char *s);
int get_char_height(uWindowPtr win,char c);

int disp_font_list();

char *title_msg[] =
{
	"Executing Calibration. Please touch mark!!",
	"TIME-OUT = %d sec",
	NULL
};
char *result_msg[] =
{
	"Saved Calibration Data!!",
	"Calibration Time Out!!",
	"Calibration EEPROM Write Error",
	NULL
};
#define	DEF_TIME_OUT	10
int time_out = DEF_TIME_OUT;
#define	MAX_POINT	9
int point_max = MAX_POINT;
uRect mark_rect_dat[MAX_POINT];
uRect adj_rect[MAX_POINT];
int point_tb[MAX_POINT][MAX_POINT] =
{
	{ -1,-1,-1,-1,-1 ,-1,-1,-1,-1 },	/* 1 */
	{  0, 8,-1,-1,-1 ,-1,-1,-1,-1 },	/* 2 */
	{  0, 4, 8,-1,-1 ,-1,-1,-1,-1 },	/* 3 */
	{  0, 2, 6, 8,-1 ,-1,-1,-1,-1 },	/* 4 */
	{  0, 2, 4, 6, 8 ,-1,-1,-1,-1 },	/* 5 */
	{  0, 2, 3, 5, 6 , 8,-1,-1,-1 },	/* 6 */
	{ -1,-1,-1,-1,-1 ,-1,-1,-1,-1 },	/* 7 */
	{ -1,-1,-1,-1,-1 ,-1,-1,-1,-1 },	/* 8 */
	{  0, 1, 2, 3, 4 , 5, 6, 7, 8 },	/* 9 */
};

/***************************************************************************
 *	
 */
int set_calibration_dat()
{
int i,pmax;
	printf("set_calibration_dat\n");
	pmax = make_adjust_xy_point(adj_rect,mark_rect_dat,point_max);
	for( i=0 ; i < pmax ; i++ )
	{
		printf("%d Adj=[%4d,%4d] ($%4x,$%4x)\n"
						,i
						,adj_rect[i].x,adj_rect[i].y
						,adj_rect[i].x,adj_rect[i].y);
	}
	return(pmax);
}
int make_adjust_xy_point(uRect adj[],uRect mark[],int point_max)
{
int w,h;
	w = (mark[0].width/2);
	h = (mark[0].height/2);
	adj[0].x = mark[0].x + w;	adj[0].y = mark[0].y + h;
	adj[1].x = mark[3].x + w;	adj[1].y = mark[3].y + h;
	adj[2].x = mark[6].x + w;	adj[2].y = mark[6].y + h;
	adj[3].x = mark[1].x + w;	adj[3].y = mark[1].y + h;
	adj[4].x = mark[4].x + w;	adj[4].y = mark[4].y + h;
	adj[5].x = mark[7].x + w;	adj[5].y = mark[7].y + h;
	adj[6].x = mark[2].x + w;	adj[6].y = mark[2].y + h;
	adj[7].x = mark[5].x + w;	adj[7].y = mark[5].y + h;
	adj[8].x = mark[8].x + w;	adj[8].y = mark[8].y + h;
	return( MAX_POINT );
}
/***************************************************************************
 *	
 */
int main(int argc,char *argv[])
{
int a;
	setbuf(stdin,0);
	setbuf(stdout,0);
	if( argc >= 2 && argv[1][0] == '-' )
		prhelp();
	else
	{
		point_max = argc >= 2 ? atoi(argv[1]) : MAX_POINT;
		if( point_max > MAX_POINT || point_tb[point_max-1][0] == -1 )
			point_max = MAX_POINT;
		time_out = argc >= 3 ? atoi(argv[2]) : DEF_TIME_OUT;
		init_ulib();
//disp_font_list();
		if( open_xinput_driver("DMC") != -1 )
		{
			a = wMain();
			if( wEndWait(a) == -1 )
				wEndWait(-2);
		}
		term_ulib();
	}
	return(0);
}
void prhelp()
{
	fprintf(stderr,"Syntax:tbcalib {<Option>} {<point> <time-out>}\n");
	fprintf(stderr,"Function: %s DMC-Touch-Panel calibration on X-Window\n",ProductName);
	fprintf(stderr,"Option:\n");
	fprintf(stderr,"    -?     help\n");
	exit(0);
}

/***************************************************************************
 *
 */
int wMain()
{
uWindowPtr win;
uRect r;
uColor fgcolor,bgcolor;
XEvent ev;
int doing;
int end,i,x,y;
KeySym key;
time_t start_sec;
int point,pmax;
char s[100];
	get_display_rect(&r);
	fgcolor = BlackPixel(gDisp,0);
	bgcolor = WhitePixel(gDisp,0);
	sprintf(s,"%s Calibration",ProductName);
	win = new_window(&r,s,fgcolor,bgcolor,true);
	show_mouse_pointer(win,true);
	XSelectInput(gDisp,win->win,NormalMask);
	doing = 0;
	start_sec = time(NULL);
	wMain_draw_win(win,0);
	pmax = set_calibration_dat();
#if USE_PIPE_COMM
	set_start_calib(adj_rect,point_max);
#else
	set_start_calib(adj_rect,pmax);
#endif
	for( end=false,point=0 ; point < point_max && !end ; )
	{
		if( difftime(time(NULL),start_sec) >= time_out )
			break;
		if( !XCheckWindowEvent(gDisp,win->win,NormalMask,&ev) )
		{
			if( !XCheckTypedEvent(gDisp,ClientMessage,&ev) )
				continue;
		}
		//XNextEvent(gDisp,&ev);
		start_sec = time(NULL);
		switch( ev.type )
		{
		case	ButtonPress:
			break;
		case	ButtonRelease:
			point++;
			set_next_calib();
			if( point < point_max )
				wMain_draw_win(win,point);
			break;
		case	MotionNotify:
			break;
		case	LeaveNotify:
			break;
		case	Expose:	/* = window draw */
			wMain_draw_win(win,point);
			break;
		case	ClientMessage:
			if( ev.xclient.message_type == win->a1 && ev.xclient.data.l[0] == win->a2 )
				end = true;
			break;
		case	DestroyNotify:
			end = true;
			break;
		}
	}
	set_end_calib();
	if( point < point_max )
		cancel_calib();
	destroy_window(win);
	return( (point >= point_max ? 0 : -1) );
}
void wMain_draw_win(uWindowPtr win,int point)
{
uRect r;
int x,y,w;
char s[100];
	//
	get_win_rect(&r,win);
	sprintf(s,title_msg[0]);
	w = get_text_width(win,s);
	x = r.x + (r.width/2) - (w/2);
	y = r.y + (r.height/4);
	XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));

	sprintf(s,title_msg[1],time_out);
	y += get_char_height(win,'A');
	XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));
	//
	wMain_draw_mark(win,point);
}
void wMain_draw_mark(uWindowPtr win,int point)
{
uRect r;
int i,x,y,w,h;
static int first = true;
	if( first )
	{
		get_win_rect(&r,win);
		w = r.width;
		h = r.height;
		for( i=0 ; i < MAX_POINT ; i++ )
		{
			x = r.x;
			y = r.y;
			switch( i )
			{
			case	0:	x = x + ADJ_X;				y = y + ADJ_Y;				break;
			case	1:	x = x + ADJ_X;				y = y + (h/2) - (H_MARK/2);	break;
			case	2:	x = x + ADJ_X;				y = y + h - ADJ_Y - H_MARK;	break;
			case	3:	x = x + (w/2) - (W_MARK/2);	y = y + ADJ_Y;				break;
			case	4:	x = x + (w/2) - (W_MARK/2);	y = y + (h/2) - (H_MARK/2);	break;
			case	5:	x = x + (w/2) - (W_MARK/2);	y = y + h - ADJ_Y - H_MARK;	break;
			case	6:	x = x + w - ADJ_X - W_MARK;	y = y + ADJ_Y;				break;
			case	7:	x = x + w - ADJ_X - W_MARK;	y = y + (h/2) - (H_MARK/2);	break;
			case	8:	x = x + w - ADJ_X - W_MARK;	y = y + h - ADJ_Y - H_MARK;	break;
			}
			set_rect(&mark_rect_dat[i],x,y,W_MARK,H_MARK);
		}
		first = false;
	}
	if( point_max > MAX_POINT || point_max <= 0 )
		point_max = MAX_POINT;
	if( point > 0 )
	{
		if( (i = point_tb[point_max-1][point-1]) == -1 )
			return;
		r = mark_rect_dat[i];
		erase_rect(win,&r);
	}
	if( (i = point_tb[point_max-1][point]) == -1 )
		return;
	r = mark_rect_dat[i];
	x = r.x + (W_MARK/2);
	y = r.y;
	XDrawLine(gDisp,win->win,win->gc,x,y,x,y+H_MARK-1);
	x = r.x;
	y = r.y + (H_MARK/2);
	XDrawLine(gDisp,win->win,win->gc,x,y,x+W_MARK-1,y);
}

/***************************************************************************
 *
 */
int wEndWait(int err)
{
uWindowPtr win;
uControlPtr ctl[3];
XEvent ev;
uRect r;
uColor fgcolor,bgcolor;
int x,y,w,h,msg_y;
int end,i,res;
Cursor cs;
time_t start_sec;
char title[100];
	get_display_rect(&r);
	fgcolor = BlackPixel(gDisp,0);
	//bgcolor = WhitePixel(gDisp,0);
	bgcolor = get_color(0xe000,0xe000,0xe000);
	w = r.width;
	h = r.height;
	x = r.x + (w / 2) - 150;
	w = 300;
	y = r.y + (h / 5);
	h = 100;
	msg_y = err == 0 ? 30 : 50;
	set_rect(&r,x,y,w,h);
	sprintf(title,"%s Calibration Result",ProductName);
	win = new_window(&r,title,fgcolor,bgcolor,false);
	XFlush(gDisp);
	XMoveWindow(gDisp,win->win,x,y);
	if( err == 0 )
	{
		set_rect(&r,(w-100-100)/2,msg_y+30,100,20);
		ctl[0] = new_control(win,PT_BUTTON,"OK",&r,false,0);
		set_rect(&r,(w-100-100)/2+110,msg_y+30,100,20);
		ctl[1] = new_control(win,PT_BUTTON,"Cancel",&r,false,0);
		ctl[2] = NULL;
	}
	//XWarpPointer(gDisp,None,win->win,0,0,0,0,(w/2),(h/2));
	XSelectInput(gDisp,win->win,NormalMask);
	wEndWait_draw_win(win,msg_y,err);
	XFlush(gDisp);
	start_sec = time(NULL);
	for( res=0,end=false ; !end ; )
	{
		if( difftime(time(NULL),start_sec) >= time_out )
		{
			if( err == 0 )
				cancel_calib();
			break;
		}
		if( !XCheckWindowEvent(gDisp,win->win,NormalMask,&ev) )
		{
			if( !XCheckTypedEvent(gDisp,ClientMessage,&ev) )
				continue;
		}
		//XNextEvent(gDisp,&ev);
		switch( ev.type )
		{
		case	ButtonPress:
			if( err == 0 )
				ctl_mouse_on(ctl,2,&ev);
			break;
		case	ButtonRelease:
			if( err == 0 )
			{
				if( (i=ctl_mouse_off(ctl,2,&ev)) == 0 ) // OK
				{
					end = true;
					cs = XCreateFontCursor(gDisp,XC_clock);
					XDefineCursor(gDisp,win->win,cs);
					XFlush(gDisp);
					if( ok_calib() == -1 )
						res = -1;
					XUndefineCursor(gDisp,win->win);
				}
				else if( i == 1 )						// Cancel
				{
					end = true;
					cancel_calib();
				}
			}
			break;
		case	Expose:	/* = window draw */
			if( err == 0 )
				draw_control(ctl,2);
			wEndWait_draw_win(win,msg_y,err);
			break;
		case	ClientMessage:
			if( ev.xclient.message_type == win->a1 && ev.xclient.data.l[0] == win->a2 )
			{
				end = true;
				if( err == 0 )
					cancel_calib();
			}
			break;
		case	DestroyNotify:
			end = true;
			break;
		}
	}
	destroy_window(win);
	XFlush(gDisp);
	return(res);
}
void wEndWait_draw_win(uWindowPtr win,int y,int err)
{
uRect r;
int i,x,w;
char s[100];
	get_win_rect(&r,win);
	if( err == 0 )
		i = 0;
	else if( err == -1 )
		i = 1;
	else
		i = 2;
	sprintf(s,result_msg[i]);
	w = get_text_width(win,s);
	x = r.x + (r.width/2) - (w/2);
	XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));
}

/***************************************************************************
 *
 */
int disp_font_list()
{
XFontStruct *fs;
char **fname;
int i,n;
	fname = XListFontsWithInfo(gDisp,"fixed",1000,&n,&fs);
	for( i=0 ; i < n ; i++ )
	{
		printf("%2d %4d %4d %s\n",i,fs[i].min_bounds.width,fs[i].max_bounds.width,fname[i]);
	}
	exit(0);
}

