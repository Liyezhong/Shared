/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
/*
 * EUC
 * tab=4
 */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
//#include <curses.h>
#include "tb.h"

#define	C_ESC	0x1b

int main(int argc,char *argv[]);
void prhelp();
void local_check(BOOL no_wm);
void draw_disp(uWindowPtr win,uRect *r);
void draw_xy(uWindowPtr win,int nx,int ny);
void draw_line(uWindowPtr win,int nx,int nt,int init);

unsigned long fgcolor,bgcolor;

int main(int argc,char *argv[])
{
BOOL no_wm;
	setbuf(stdin,0);
	setbuf(stdout,0);
	if( argc >= 2 && argv[1][0] == '-' )
		prhelp();
	else
	{
		no_wm = argc >= 2 ? atoi(argv[1]) : false;
		local_check(no_wm);
	}
	return(0);
}
void prhelp()
{
	fprintf(stderr,"Syntax:tbtest {<Option>} \n");
	fprintf(stderr,"Function: %s DMC touch-panel check on X-Window\n",ProductName);
	fprintf(stderr,"Option:\n");
	fprintf(stderr,"    -?     help\n");
	exit(0);
}

void local_check(BOOL no_wm)
{
uWindowPtr win;
XEvent ev;
uRect r;
int doing;
int end,i;
KeySym key;
uColor c1,c2,c3,c;
char s[100];
	init_ulib();
	get_display_rect(&r);
	fgcolor = BlackPixel(gDisp,0);
	bgcolor = WhitePixel(gDisp,0);
	sprintf(s,"%s Panel Test",ProductName);
	win = new_window(&r,s,fgcolor,bgcolor,no_wm);
	XSelectInput(gDisp,win->win,NormalMask);
	draw_disp(win,&r);
	c1 = get_color(0,0,0);
	c2 = get_color(0xffff,0,0);
	c3 = get_color(0,0xffff,0);
	doing = 0;
	for( end=0 ; !end ; )
	{
		XNextEvent(gDisp,&ev);
		switch( ev.type )
		{
		case	KeyPress:
			if( XLookupString(&ev.xkey,s,10,&key,NULL) >= 1 && s[0] == C_ESC )
				end = true;
			//printf("in %x\n",s[0]);
			break;
		case	ButtonPress:
			doing = true;
			//printf("state = $%x\n",ev.xbutton.button);
			switch( ev.xbutton.button )
			{
			case	2:	c = c2;	break;
			case	3:	c = c3;	break;
			default:	c = c1;	break;
			}
			XSetForeground(gDisp,win->gc,c);
			draw_line(win,ev.xbutton.x,ev.xbutton.y,false);
			draw_xy(win,ev.xbutton.x,ev.xbutton.y);
			break;
		case	MotionNotify:
			if( doing )
			{
				XSetForeground(gDisp,win->gc,c);
				draw_line(win,ev.xmotion.x,ev.xmotion.y,false);
				draw_xy(win,ev.xmotion.x,ev.xmotion.y);
			}
			break;
		case	LeaveNotify:
		case	ButtonRelease:
			doing = false;
			XSetForeground(gDisp,win->gc,c);
			draw_line(win,0,0,true);
			draw_xy(win,ev.xbutton.x,ev.xbutton.y);
			break;
		case	Expose:	/* = window draw */
			draw_disp(win,&r);
			break;
		case	ClientMessage:
			if( ev.xclient.message_type == win->a1 && ev.xclient.data.l[0] == win->a2 )
				end = 1;
			break;
		case	DestroyNotify:
			end = 1;
			break;
		}
	}
	destroy_window(win);
	term_ulib();
}
void draw_disp(uWindowPtr win,uRect *r)
{
char s[100];
int x,y,w;
	sprintf(s,"Exit when input ESC key OR click window-close button.");
	w = get_text_width(win,s);
	x = r->x + (r->width / 2) - (w /2);
	y = r->y + (r->height / 3);
	XDrawString(gDisp,win->win,win->gc,x,y,s,strlen(s));
}
void draw_xy(uWindowPtr win,int nx,int ny)
{
char s[100];
int tx,ty,w,h;
uRect r;
	sprintf(s,"(%4d,%4d)",nx,ny);
	w = get_text_width(win,s);
	h = get_char_height(win,'A');
	tx = 5;
	ty = 5 + h;
	set_rect(&r,5,5,w,h);
	erase_rect(win,&r);
	//XSetFunction(gDisp,win->gc,GXcopy);
	//XSetPlaneMask(gDisp,win->gc,0xffffffff);
	XDrawString(gDisp,win->win,win->gc,tx,ty,s,strlen(s));
}
void draw_line(uWindowPtr win,int nx,int ny,int init)
{
static int sx,sy;
static int first = true;
	if( init )
	{
		first = true;
		return;
	}
	if( first )
	{
		first = false;
		sx = nx;
		sy = ny;
		return;
	}
	//printf("(%d,%d) -> (%d,%d) \n",sx,sy,nx,ny);
	XDrawLine(gDisp,win->win,win->gc,sx,sy,nx,ny);
	sx = nx;
	sy = ny;
}

