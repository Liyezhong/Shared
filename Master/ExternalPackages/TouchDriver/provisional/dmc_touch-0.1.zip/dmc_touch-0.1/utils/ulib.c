/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
/*
 * EUC
 * tab=4
 */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include "tb.h"

#define	DEF_FONT	"fixed"

Display *gDisp;
Colormap gCM;

static void draw_button(uControlPtr ctl,BOOL state);
static void draw_radio(uControlPtr ctl,BOOL state);
static void draw_ckbox(uControlPtr ctl,BOOL state);
static void draw_stext(uControlPtr ctl);
static void draw_line(uControlPtr ctl);
static void same_group_off(uControlPtr ctl[],int num,XEvent *ev,int group);

/*
 * init/term function
 */
void init_ulib()
{
	gDisp = XOpenDisplay(NULL);
	gCM = DefaultColormap(gDisp,0);
}
void term_ulib()
{
	XCloseDisplay(gDisp);
}
/*
 * common function
 */
void get_display_rect(uRect *r)
{
int w,h;
	w = DisplayWidth(gDisp,0);
	h = DisplayHeight(gDisp,0);
	set_rect(r,0,0,w,h);
}
void erase_rect(uWindowPtr win,uRect *r)
{
	XSetForeground(gDisp,win->gc,win->bgcolor);
    XFillRectangle(gDisp,win->win,win->gc,r->x,r->y,r->width,r->height);
	XSetForeground(gDisp,win->gc,win->fgcolor);
}
void set_rect(uRect *r,int x,int y,int w,int h)
{
	r->x = x;
	r->y = y;
	r->width = w;
	r->height = h;
}
int pt_in_rect(uRect *r,int x,int y)
{
int ax,ay;
	ax = x - r->x;
	ay = y - r->y;
	if( ax >= 0 && ax < r->width && ay >= 0 && ay < r->height )
		return(1);
	return(0);
}
void get_win_rect(uRect *r,uWindowPtr win)
{
int x,y;
unsigned int w,h,b,d;
Window ww;
	ww = win->win;
	XGetGeometry(gDisp,ww,&ww,&x,&y,&w,&h,&b,&d);
	set_rect(r,x,y,w,h);
}
int get_text_width(uWindowPtr win,char *s)
{
XFontStruct *f;
XGCValues v;
	XGetGCValues(gDisp,win->gc,GCFont,&v);
	if( (f = XQueryFont(gDisp,v.font)) != NULL )
		return( XTextWidth(f,s,strlen(s)) );
	return( strlen(s) * 8 );
}
int get_char_height(uWindowPtr win,char c)
{
XFontStruct *f;
XGCValues v;
	XGetGCValues(gDisp,win->gc,GCFont,&v);
	if( (f = XQueryFont(gDisp,v.font)) != NULL )
		return( f->ascent + f->descent );
	return(16);
}
uColor get_color(unsigned short r,unsigned short g,unsigned short b)
{
	XColor c1;
    c1.red   = r;
    c1.green = g;
    c1.blue  = b;
    XAllocColor(gDisp,gCM,&c1);
    return( c1.pixel );
}

/*
 * window function
 */
uWindowPtr new_window(uRect *r,char *wname,uColor fgcolor,uColor bgcolor,BOOL no_wm)
{
uWindowPtr p;
XSetWindowAttributes attr;
XFontStruct *fs;
	if( (p = (uWindowPtr)malloc(sizeof(uWindowRec))) == NULL )
		return(NULL);
	memset(p,0,sizeof(uWindowRec));
	p->dsp = gDisp;
	p->win = XCreateSimpleWindow(gDisp,
				DefaultRootWindow(gDisp),
				r->x,
				r->y,
				r->width,
				r->height,
				2,
				fgcolor,
				bgcolor);
	if( p->win == 0 )
	{
		free(p);
		return(NULL);
	}
	p->a1 = p->a2 = 0;
	if( !no_wm )
	{
		p->a1 = XInternAtom(gDisp,"WM_PROTOCOLS",false);
		p->a2 = XInternAtom(gDisp,"WM_DELETE_WINDOW",false);
		XSetWMProtocols(gDisp,p->win,&p->a2,1);
	}
	if( wname != NULL && wname[0] != 0 )
		XStoreName(gDisp,p->win,wname);
	if( no_wm )
	{
		attr.override_redirect = true;
		XChangeWindowAttributes(gDisp,p->win,CWOverrideRedirect,&attr);
	}
	XSelectInput(gDisp,p->win,NormalMask);
	XMoveWindow(gDisp,p->win,r->x,r->y);
	XMapWindow(gDisp,p->win);
	p->gc = XCreateGC(gDisp,p->win,0,0);
	if( (fs = XLoadQueryFont(gDisp,DEF_FONT)) != NULL )
		XSetFont(gDisp,p->gc,fs->fid);
	p->fgcolor = fgcolor;
	p->bgcolor = bgcolor;
	p->ctl = NULL;
	p->ctl_type = PT_WIN;
	p->cs = 0;
	XFlush(gDisp);
	return(p);
}
void destroy_window(uWindowPtr win)
{
uControlPtr n1,n2;
	for( n1=(uControlPtr)win->ctl ; n1 ; n1=n2 )
	{
		n2 = (uControlPtr)n1->ctl;
		destroy_control(n1);
	}
	XDestroyWindow(gDisp,win->win);
	free(win);
}
/*
 * 
 */
void show_mouse_pointer(uWindowPtr win,int show)
{
	if( show )
	{
		XColor c1,cc;
		Colormap cm;
		Font f1;
		cm = DefaultColormap(gDisp,0);
		f1 = XLoadFont(gDisp,DEF_FONT);
		XAllocNamedColor(gDisp,cm,"white",&c1,&cc);
		win->cs = XCreateGlyphCursor(gDisp,f1,f1,' ',' ',&c1,&c1);
		XDefineCursor(gDisp,win->win,win->cs);
	}
	else
	{
		XFreeCursor(gDisp,win->cs);
		win->cs = 0;
	}
}
/*
 * control object function
 */
uControlPtr new_control(uWindowPtr win,int type,char *str,uRect *r,int state,int group)
{
uControlPtr p,n1,n2;
char *s;
	if( (p = (uControlPtr)malloc(sizeof(uControlRec))) == NULL )
		return(NULL);
	if( (s = (char *)malloc(strlen(str)+1)) == NULL )
	{
		free(p);
		return(NULL);
	}
	memset(p,0,sizeof(uControlRec));
	strcpy(s,str);
	p->dsp = gDisp;
#ifdef USE_CHILD_WIN
	p->win = XCreateSimpleWindow(gDisp,
				win->win,
				r->x,
				r->y,
				r->width,
				r->height,
				0,
				win->fgcolor,
				win->bgcolor);
	if( p->win == 0 )
	{
		free(s);
		free(p);
		return(NULL);
	}
	XMoveWindow(gDisp,p->win,r->x,r->y);
	//XMapSubwindows(gDisp,p->win);
	p->gc = XCreateGC(gDisp,p->win,0,0);
	if( (fs = XLoadQueryFont(gDisp,DEF_FONT)) != NULL )
		XSetFont(gDisp,p->gc,fs->fid);
#else
	p->win = win->win;
	p->gc = win->gc;
#endif
	p->fgcolor = win->fgcolor;
	p->bgcolor = win->bgcolor;
	set_rect(&p->r,r->x,r->y,r->width,r->height);
	p->ctl_type = type;
	p->state = state;
	p->group = group;
	p->s = s;
	p->ctl = NULL;
	if( win->ctl )
	{
		for( n1=(uControlPtr)win->ctl ; n1 ; n1=(uControlPtr)n1->ctl )
			n2 = n1;
		n2->ctl = p;
	}
	else
		win->ctl = p;
	switch( type )
	{
	case	PT_BUTTON:	draw_button(p,p->state);	break;
	case	PT_GBUTTON:	draw_button(p,p->state);	break;
	case	PT_RADIO:	draw_radio(p,p->state);		break;
	case	PT_CKBOX:	draw_ckbox(p,p->state);		break;
	case	PT_STEXT:	draw_stext(p);				break;
	case	PT_LINE:	draw_line(p);				break;
	}
	return(p);
}
void destroy_control(uControlPtr ctl)
{
	free(ctl->s);
	free(ctl);
}
static void draw_button(uControlPtr ctl,BOOL state)
{
uRect r;
int x,y,w,h;
static uColor fg,bg,mg;
static BOOL first = true;
	if( first )
	{
		fg = BlackPixel(gDisp,0);
		mg = WhitePixel(gDisp,0);
		bg = get_color(0xe000,0xe000,0xe000);
		first = false;
	}
	r = ctl->r;
#ifdef USE_CHILD_WIN
	r.x = 0;
	r.y = 0;
#else
	x = r.x;
	y = r.y;
#endif
	w = r.width;
	h = r.height;
	XSetForeground(gDisp,ctl->gc,(state==STATE_ON?fg:mg));
    XDrawLine(gDisp,ctl->win,ctl->gc,x,y,x+w,y);
    XDrawLine(gDisp,ctl->win,ctl->gc,x,y,x,y+h);
	XSetForeground(gDisp,ctl->gc,(state==STATE_ON?mg:fg));
    XDrawLine(gDisp,ctl->win,ctl->gc,x+w,y,x+w,y+h);
    XDrawLine(gDisp,ctl->win,ctl->gc,x,y+h,x+w,y+h);
	XSetForeground(gDisp,ctl->gc,fg);
	w = get_text_width(ctl,ctl->s);
	h = get_char_height(ctl,'A');
    x = r.x + (r.width/2) - (w/2);
    y = r.y + (r.height/2) + (h/2)-1;
	XDrawString(gDisp,ctl->win,ctl->gc,x,y,ctl->s,strlen(ctl->s));
}
static void draw_radio(uControlPtr ctl,BOOL state)
{
#define	W_RADIO	14
#define	A_RADIO	3
uRect r;
int x,y;
static uColor fg,bg,mg;
static BOOL first = true;
	if( first )
	{
		fg = BlackPixel(gDisp,0);
		mg = WhitePixel(gDisp,0);
		bg = get_color(0xe000,0xe000,0xe000);
		first = false;
	}
	r = ctl->r;
#ifdef USE_CHILD_WIN
	r.x = 0;
	r.y = 0;
#else
	x = r.x;
	y = r.y;
#endif
	XSetForeground(gDisp,ctl->gc,fg);
    XDrawArc(gDisp,ctl->win,ctl->gc,x,y,W_RADIO,W_RADIO,0,360*64);
	XSetForeground(gDisp,ctl->gc,(state==STATE_ON?fg:bg));
    XFillArc(gDisp,ctl->win,ctl->gc,x+A_RADIO,y+A_RADIO
						,W_RADIO-(A_RADIO*2),W_RADIO-(A_RADIO*2),0,360*64);
	XSetForeground(gDisp,ctl->gc,fg);
    x = r.x + W_RADIO + 5;
    y = r.y + W_RADIO - A_RADIO;
	XDrawString(gDisp,ctl->win,ctl->gc,x,y,ctl->s,strlen(ctl->s));
}
static void draw_ckbox(uControlPtr ctl,BOOL state)
{
#define	W_RADIO	14
#define	A_RADIO	3
uRect r;
int x,y,w,h;
static uColor fg,bg,mg;
static BOOL first = true;
	if( first )
	{
		fg = BlackPixel(gDisp,0);
		mg = WhitePixel(gDisp,0);
		bg = get_color(0xe000,0xe000,0xe000);
		first = false;
	}
	r = ctl->r;
#ifdef USE_CHILD_WIN
	r.x = 0;
	r.y = 0;
#else
	x = r.x;
	y = r.y;
#endif
	w = W_RADIO;
	h = W_RADIO;
	XSetForeground(gDisp,ctl->gc,mg);
    XDrawLine(gDisp,ctl->win,ctl->gc,x,y,x+w,y);
    XDrawLine(gDisp,ctl->win,ctl->gc,x,y,x,y+h);
	XSetForeground(gDisp,ctl->gc,fg);
    XDrawLine(gDisp,ctl->win,ctl->gc,x+w,y,x+w,y+h);
    XDrawLine(gDisp,ctl->win,ctl->gc,x,y+h,x+w,y+h);
	XSetForeground(gDisp,ctl->gc,(state==STATE_ON?fg:bg));
    XDrawLine(gDisp,ctl->win,ctl->gc,x+2,y+2,x+w-3,y+h-3);
    XDrawLine(gDisp,ctl->win,ctl->gc,x+w-3,y+2,x+2,y+h-3);
	XSetForeground(gDisp,ctl->gc,fg);
    x = r.x + W_RADIO + 5;
    y = r.y + W_RADIO - A_RADIO;
	XDrawString(gDisp,ctl->win,ctl->gc,x,y,ctl->s,strlen(ctl->s));
}
static void draw_stext(uControlPtr ctl)
{
uRect r;
int x,y,w,h;
static uColor fg,bg,mg;
static BOOL first = true;
	if( first )
	{
		fg = BlackPixel(gDisp,0);
		mg = WhitePixel(gDisp,0);
		bg = get_color(0xe000,0xe000,0xe000);
		first = false;
	}
	r = ctl->r;
#ifdef USE_CHILD_WIN
	r.x = 0;
	r.y = 0;
#else
	x = r.x;
	y = r.y;
#endif
	XSetForeground(gDisp,ctl->gc,fg);
	w = get_text_width(ctl,ctl->s);
	h = get_char_height(ctl,'A');
	switch( ctl->state )
	{
	case	STATE_LEFT:		x = r.x;						break;
	case	STATE_CENTOR:	x = r.x + (r.width/2) - (w/2);	break;
	case	STATE_RIGHT:	x = r.x + r.width - w;			break;
	}
    y = r.y + (r.height/2) + (h/2);
	XDrawString(gDisp,ctl->win,ctl->gc,x,y,ctl->s,strlen(ctl->s));
}
static void draw_line(uControlPtr ctl)
{
uRect r;
int x,y,w,h;
static uColor fg,bg,mg;
static BOOL first = true;
	if( first )
	{
		fg = BlackPixel(gDisp,0);
		mg = WhitePixel(gDisp,0);
		bg = get_color(0xe000,0xe000,0xe000);
		first = false;
	}
	r = ctl->r;
#ifdef USE_CHILD_WIN
	r.x = 0;
	r.y = 0;
#else
	x = r.x;
	y = r.y;
#endif
	XSetForeground(gDisp,ctl->gc,fg);
	XDrawLine(gDisp,ctl->win,ctl->gc,x,y,x+r.width,y+r.height);
}
/*
 *
 */
int ctl_mouse_on(uControlPtr ctl[],int num,XEvent *ev)
{
int i;
	for( i=0 ; i < num ; i++ )
	{
		switch( ctl[i]->ctl_type )
		{
		case	PT_BUTTON:
			if( pt_in_rect(&ctl[i]->r,ev->xbutton.x,ev->xbutton.y) )
			{
				ctl[i]->state = STATE_ON;
				draw_button(ctl[i],ctl[i]->state);
				return(i);
			}
			break;
		case	PT_GBUTTON:
		case	PT_RADIO:
			if( pt_in_rect(&ctl[i]->r,ev->xbutton.x,ev->xbutton.y) )
			{
				if( ctl[i]->state == STATE_ON && ctl[i]->group > 0 )
					return(-1);
				ctl[i]->state = ctl[i]->state == STATE_ON ? STATE_OFF : STATE_ON;
				if( ctl[i]->ctl_type == PT_RADIO )
					draw_radio(ctl[i],ctl[i]->state);
				else
					draw_button(ctl[i],ctl[i]->state);
				if( ctl[i]->group > 0 )
					same_group_off(ctl,num,ev,ctl[i]->group);
				return(i);
			}
			break;
		case	PT_CKBOX:
			if( pt_in_rect(&ctl[i]->r,ev->xbutton.x,ev->xbutton.y) )
			{
				ctl[i]->state = ctl[i]->state == STATE_ON ? STATE_OFF : STATE_ON;
				draw_ckbox(ctl[i],ctl[i]->state);
				return(i);
			}
			break;
		}
	}
	return(-1);
}
static void same_group_off(uControlPtr ctl[],int num,XEvent *ev,int group)
{
int i;
	for( i=0 ; i < num ; i++ )
	{
		switch( ctl[i]->ctl_type )
		{
		case	PT_GBUTTON:
		case	PT_RADIO:
			if( ctl[i]->group == group && !pt_in_rect(&ctl[i]->r,ev->xbutton.x,ev->xbutton.y) )
			{
				ctl[i]->state = STATE_OFF;
				if( ctl[i]->ctl_type == PT_RADIO )
					draw_radio(ctl[i],ctl[i]->state);
				else
					draw_button(ctl[i],ctl[i]->state);
			}
			break;
		}
	}
}
int ctl_mouse_off(uControlPtr ctl[],int num,XEvent *ev)
{
int i;
	for( i=0 ; i < num ; i++ )
	{
		switch( ctl[i]->ctl_type )
		{
		case	PT_BUTTON:
			if( ctl[i]->state == STATE_ON )
			{
				ctl[i]->state = STATE_OFF;
				draw_button(ctl[i],ctl[i]->state);
				if( pt_in_rect(&ctl[i]->r,ev->xbutton.x,ev->xbutton.y) )
					return(i);
			}
			break;
		}
	}
	return(-1);
}
int set_radio_group_state(uControlPtr ctl[],int pt,int num)
{
int i,g;
	g = ctl[pt]->group;
	ctl[pt]->state = STATE_ON;;
	for( i=0 ; i < num ; i++ )
	{
		if( i == pt )
			continue;
		switch( ctl[i]->ctl_type )
		{
		case	PT_GBUTTON:
		case	PT_RADIO:
			if( ctl[i]->group == g )
				ctl[i]->state = STATE_OFF;
			break;
		}
	}
	return(0);
}
int find_radio_group_on(uControlPtr ctl[],int num,int group)
{
int i;
	for( i=0 ; i < num ; i++ )
	{
		switch( ctl[i]->ctl_type )
		{
		case	PT_GBUTTON:
		case	PT_RADIO:
			if( ctl[i]->group == group && ctl[i]->state == STATE_ON )
				return(i);
			break;
		}
	}
	return(-1);
}
int draw_control(uControlPtr ctl[],int num)
{
int i;
	for( i=0 ; i < num && ctl[i] ; i++ )
	{
		switch( ctl[i]->ctl_type )
		{
		case	PT_BUTTON:	draw_button(ctl[i],ctl[i]->state);	break;
		case	PT_GBUTTON:	draw_button(ctl[i],ctl[i]->state);	break;
		case	PT_RADIO:	draw_radio(ctl[i],ctl[i]->state);	break;
		case	PT_CKBOX:	draw_ckbox(ctl[i],ctl[i]->state);	break;
		case	PT_STEXT:	draw_stext(ctl[i]);					break;
		case	PT_LINE:	draw_line(ctl[i]);					break;
		}
	}
	return(0);
}

/***************************************************************************
 *
 */
int msgbox(char *title,char *msg,int type)
{
uWindowPtr win;
uControlPtr ctl[3];
XEvent ev;
uRect r;
uColor fgcolor,bgcolor;
int x,y,w,h,msg_y;
int end,i,res,ctlnum;
	get_display_rect(&r);
	fgcolor = BlackPixel(gDisp,0);
	//bgcolor = WhitePixel(gDisp,0);
	bgcolor = get_color(0xe000,0xe000,0xe000);
	w = r.width;
	h = r.height;
	x = r.x + (w / 2) - 150;
	w = 300;
	y = r.y + (h / 5);
	h = 100;
	msg_y = 30;
	set_rect(&r,x,y,w,h);
	win = new_window(&r,title,fgcolor,bgcolor,false);
	XMoveWindow(gDisp,win->win,x,y);
	switch( type )
	{
		case MB_OKCANCEL:
			set_rect(&r,(w-100-100)/2,msg_y+30,100,20);
			ctl[0] = new_control(win,PT_BUTTON,"OK",&r,false,0);
			set_rect(&r,(w-100-100)/2+110,msg_y+30,100,20);
			ctl[1] = new_control(win,PT_BUTTON,"Cancel",&r,false,0);
			ctl[2] = NULL;
			ctlnum = 2;
			break;
		case MB_OK:
			set_rect(&r,(w/2)-(100/2),msg_y+30,100,20);
			ctl[0] = new_control(win,PT_BUTTON,"OK",&r,false,0);
			ctl[1] = NULL;
			ctlnum = 1;
			break;
	}
	XFlush(gDisp);
	//XWarpPointer(gDisp,None,win->win,0,0,0,0,(w/2),(h/2));
	XSelectInput(gDisp,win->win,NormalMask);
	XFlush(gDisp);
	for( res=0,end=false,ev.type=Expose ; !end ; )
	{
		if( ev.type == Expose )
		{
			draw_control(ctl,ctlnum);
			get_win_rect(&r,win);
			w = get_text_width(win,msg);
			x = (r.width/2) - (w/2);
			XDrawString(gDisp,win->win,win->gc,x,msg_y,msg,strlen(msg));
		}
		XNextEvent(gDisp,&ev);
		switch( ev.type )
		{
		case	ButtonPress:
			ctl_mouse_on(ctl,ctlnum,&ev);
			break;
		case	ButtonRelease:
			if( (i=ctl_mouse_off(ctl,ctlnum,&ev)) == 0 ) // OK
				end = true;
			else if( i == 1 )						// Cancel
				end = true;
			break;
		case	Expose:	/* = window draw */
			break;
		case	ClientMessage:
			if( ev.xclient.message_type == win->a1 && ev.xclient.data.l[0] == win->a2 )
				end = true;
			break;
		case	DestroyNotify:
			end = true;
			break;
		}
	}
	destroy_window(win);
	XFlush(gDisp);
	return(res);
}
int kbhit()
{
	return( io_rdy(fileno(stdin)) );
}
int io_rdy(int path)
{
fd_set rfds;
struct timeval tv;
int ret;
	/* stdin (fd 0) ��ƻ뤷�����Ϥ����ä�����ɽ�����롣*/
	FD_ZERO(&rfds);
	FD_SET(path, &rfds);
	tv.tv_sec = 0;
	tv.tv_usec = 10*1000;
	ret = select(path+1, &rfds, NULL, NULL, &tv);
	return( ret <= 0 ? false : true );
}

int find_ps(char *str)
{
char *av[3];
int i,len,pid;
int pfd;
char c,s[256];
	av[0] = "ps";
	av[1] = "-A";
	av[2] = 0;
	if( (pfd = do_exec(av,&pid)) < 0 )
		return(false);
	for( i=0,len=0 ; ; )
	{
		if( read(pfd,&c,1) <= 0 )
		{
			close(pfd);
			return(false);
		}
		switch( c )
		{
			case	0x0a:
				if( len > 0 )
				{
					i++;
					if( find_str(str,s) )
						return(true);
				}
				len = 0;
				s[len] = 0;
				break;
			case	0x0d:
				len = 0;
				s[len] = 0;
				break;
			default:
				if( len >= (256-10) )
					break;
				s[len++] = c;
				s[len] = 0;
				break;
		}
	}
}
int find_str(char *str,char *s)
{
int i;
	for( ; *s ; s++ )
	{
		for( i=0 ; str[i] ; i++ )
		{
			if( str[i] != s[i] )
				break;
		}
		if( str[i] == 0 )
			return(true);
	}
	return(false);
}
int do_exec(char *av[],int *pid)
{
int pfd[2];
	if( pipe(pfd) < 0 )
		return(-1);
	if( (*pid = fork()) < 0 )
		return(-1);
	if( *pid > 0 )
	{
		close(pfd[1]);
		return(pfd[0]);
	}
	close(1);
	dup(pfd[1]);
	close(2);
	dup(pfd[1]);
	close(pfd[0]);
	close(pfd[1]);
	execvp(av[0],av);
	perror(av[0]);
	exit(1);
}
