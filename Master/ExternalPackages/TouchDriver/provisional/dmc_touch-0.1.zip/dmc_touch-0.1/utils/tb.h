/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
#ifndef TBCTL_H
#define TBCTL_H

#include <stdlib.h>
#include <string.h>

//#define	_3MEX2

#ifdef	_3MEX2
#define	ProductName	"DCA-10/LD"
#else
#define	ProductName	"TSC-10/LD"
#endif

#ifndef true
#define true	1
#endif
#ifndef false
#define false	0
#endif

#define NormalMask  (KeyPressMask|KeyReleaseMask\
                    |LeaveWindowMask|EnterWindowMask\
                    |ButtonPressMask|ButtonReleaseMask|PointerMotionMask\
                    |DestroyNotify|ExposureMask)

typedef XRectangle uRect;
typedef unsigned long uColor;
typedef int BOOL;

typedef struct uWindowRec
{
	Display *dsp;
	Window win;
	GC gc;
	uRect r;
	Atom a1,a2;
	uColor fgcolor,bgcolor;
	void *ctl;
	int ctl_type;	// use Control
#define	PT_WIN		0
#define	PT_BUTTON	1
#define	PT_RADIO	2
#define	PT_CKBOX	3
#define	PT_STEXT	4
#define	PT_LINE		5
#define	PT_GBUTTON	6
	int state;		// use Control
#define	STATE_OFF		0
#define	STATE_ON		1
#define	STATE_DOING		2
#define	STATE_LEFT		3
#define	STATE_CENTOR	4
#define	STATE_RIGHT		5
	int group;
	char *s;		// use Control
	Cursor cs;
} uWindowRec,*uWindowPtr;

typedef uWindowRec uControlRec,*uControlPtr;

typedef struct uPane
{
	int type;
	int x,y,w,h;
	int state;
	char *s;
} uPane;

extern Display *gDisp;
extern Colormap gCM;

/*
 * tbcalib's calib point mark size
 */
#define	ADJ_X	15
#define	ADJ_Y	15
#define	W_MARK	20
#define	H_MARK	20

/*
 * common library
 */
void init_ulib();
void term_ulib();
void get_display_rect(uRect *r);
void set_rect(uRect *r,int x,int y,int w,int h);
int pt_in_rect(uRect *r,int x,int y);
void get_win_rect(uRect *r,uWindowPtr win);
int get_text_width(uWindowPtr win,char *s);
int get_char_height(uWindowPtr win,char c);
uColor get_color(unsigned short r,unsigned short g,unsigned short b);

uWindowPtr new_window(uRect *r,char *wname
				,uColor fgcolor,uColor bgcolor,BOOL no_wm);
void destroy_window(uWindowPtr win);

void show_mouse_pointer(uWindowPtr win,int show);

uControlPtr new_control(uWindowPtr win,int type,char *str,uRect *r
												,int state,int group);
void destroy_control(uControlPtr ctl);

int ctl_mouse_on(uControlPtr ctl[],int num,XEvent *ev);
int ctl_mouse_off(uControlPtr ctl[],int num,XEvent *ev);
int set_radio_group_state(uControlPtr ctl[],int pt,int num);
int find_radio_group_on(uControlPtr ctl[],int num,int group);
int draw_control(uControlPtr ctl[],int num);

int open_xinput_driver(char *driver_name);

int set_raw_mode(int on);
int is_selector_on();
int select_button(int bttn);
int set_samp_rate(int s_rate);
int get_samp_rate();
int get_calib_point_num();
int set_beep(int pen_down,int on);
int get_beep();
int save_exec();

int set_start_calib(uRect adj[],int count);
int set_next_calib();
int set_end_calib();
int cancel_calib();
int ok_calib();

int msgbox(char *title,char *msg,int type);
#define	MB_OKCANCEL		0
#define	MB_OK			1

int kbhit();
int io_rdy(int path);

int find_ps(char *str);
int find_str(char *str,char *s);
int do_exec(char *av[],int *pid);

#endif //TBCTL_H

