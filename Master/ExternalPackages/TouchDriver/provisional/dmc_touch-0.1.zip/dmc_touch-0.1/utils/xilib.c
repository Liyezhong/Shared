/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
/*
 * EUC
 * tab=4
 */
#include <X11/Xlib.h>
#include <X11/extensions/XI.h>
#include <X11/extensions/XInput.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
//#include <curses.h>
#include "tb.h"
#include "../driver/cmd.h"

#if 1
#define	PRINT(a,b,c,d,e)	printf(a,b,c,d,e)
#else
#define	PRINT(a,b,c,d,e)
#endif

static XDeviceInfo *info = NULL;
static XDevice *dev = NULL;
static XDeviceControl *dctl = NULL;
static char drvname[100];

static int do_set_calib(u_short dat);
static XDeviceInfo *find_device_info(Display *display,char *name, Bool only_extended);

#if USE_PIPE_COMM
static int pipe_open(char *name);
static int send_dmcpkt(int cmd,char *dat,int size);
static int recv_dmcpkt(int cmd);

static int pinfd = -1;
static int poutfd = -1;
char rxname[] = DMC_PIPE_RX_FILE;
char txname[] = DMC_PIPE_TX_FILE;
#endif

int open_xinput_driver(char *driver_name)
{
int ctype,res;
char s[512];
#if USE_PIPE_COMM
	if( (poutfd=pipe_open(txname)) == -1 )
	{
		PRINT("error : out-pipe open\n",0,0,0,0);
		return(-1);
	}
	if( (pinfd=pipe_open(rxname)) == -1 )
	{
		PRINT("error : in-pipe open\n",0,0,0,0);
		return(-1);
	}
#endif
	strcpy(drvname,driver_name);
	if( info == NULL && (info = find_device_info(gDisp, drvname, 1)) == NULL )
	{
		PRINT("error : find device [%s]\n",drvname,0,0,0);
		return(-1);
	}
	PRINT("device [%s]\n",drvname,0,0,0);
	if( dev == NULL && (dev = XOpenDevice(gDisp,info->id)) == NULL )
	{
		PRINT("error : open device [%s]\n",drvname,0,0,0);
		return(-1);
	}
	PRINT("open device [%s]\n",drvname,0,0,0);
#if 0
	ctype = DEVICE_RESOLUTION;
	if( dctl == NULL && (dctl = XGetDeviceControl(gDisp,dev,ctype)) == NULL )
	{
		PRINT("error : get device [%s]\n",drvname,0,0,0);
		return(-1);
	}
	PRINT("get device [%s]\n",drvname,0,0,0);
#endif
	return(0);
}
int test_xidrv()
{
int res;
unsigned long a;
	if( dev == NULL )
		return(-1);
	a = 0xf8;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("test_xidrv [%s] res=%d \n",drvname,res,a,0);
	return( 0 );
}
int set_raw_mode(int on)
{
int res;
unsigned long a;
	if( dev == NULL )
		return(-1);
	a = on ? TS_Raw : TS_Scaled;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("set_raw_mode [%s] res=%d \n",drvname,res,a,0);
	return( 0 );
}
int is_selector_on()
{
int res;
unsigned long a;
#if USE_PIPE_COMM
u_short dat;
#endif
	if( dev == NULL )
		return(-1);
#if USE_PIPE_COMM
	res = send_dmcpkt(GET_SELECTOR_CMD,(char *)&dat,sizeof(dat));
	//PRINT("is_selector_on [%s] res=%d \n",drvname,res,0,0);
	if( res >= 0 && res <= 2 )
		return(res);
	return(-1);
#else
	a = GET_SELCT_MID_CMD;
	if( XSetDeviceMode(gDisp,dev,a) == Success )
		return( 1 );
	a = GET_SELCT_RIGHT_CMD;
	if( XSetDeviceMode(gDisp,dev,a) == Success )
		return( 2 );
	return( 0 );
#endif
}
int select_button(int bttn)	/* 0=left/1=middle/2=right */
{
int res;
unsigned long a;
#if USE_PIPE_COMM
u_short dat;
#endif
	if( dev == NULL )
		return(-1);
#if USE_PIPE_COMM
	dat = bttn;
	res = send_dmcpkt(SET_SELECTOR_CMD,(char *)&dat,sizeof(dat));
	PRINT("select_tb [%s] res=%d \n",drvname,res,0,0);
	return( res );
#else
	a = SELCT_CMD + bttn;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("select_tb [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return( (res == 0 ? 0 : -1) );
#endif
}
int reset_tb()
{
int res;
unsigned long a;
#if USE_PIPE_COMM
u_short dat;
#endif
	if( dev == NULL )
		return(-1);
#if USE_PIPE_COMM
	dat = 0;
	res = send_dmcpkt(RESET_CMD,(char *)&dat,sizeof(dat));
	PRINT("reset_tb [%s] res=%d \n",drvname,res,0,0);
	return(res);
#else
	a = RESET_CMD;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("reset_tb [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return( (res == 0 ? 0 : -1) );
#endif
}
int set_samp_rate(int s_rate)
{
int res;
unsigned long a;
#if USE_PIPE_COMM
u_short dat;
#endif
	if( dev == NULL )
		return(-1);
	if( s_rate < 0 || s_rate > 5 )
		return(-1);
#if USE_PIPE_COMM
	dat = s_rate;
	res = send_dmcpkt(SET_RATE_CMD,(char *)&dat,sizeof(dat));
	PRINT("set_samp_rate [%s] res=%d \n",drvname,res,0,0);
	return(res);
#else
	a = S_RATE_CMD + s_rate;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("set_samp_rate [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return( (res == 0 ? 0 : -1) );
#endif
}
int get_samp_rate()
{
#if USE_PIPE_COMM
int res;
u_short dat;
	if( dev == NULL )
		return(-1);
	res = send_dmcpkt(GET_RATE_CMD,(char *)&dat,sizeof(dat));
	PRINT("get samp_rate [%s] %d\n",drvname,res,0,0);
	if( res >= 0 && res <= 5 )
		return(res);
	return(-1);
#else
	return(0);
#endif
}
int get_calib_point_num()
{
#if USE_PIPE_COMM
int res;
u_short dat;
	if( dev == NULL )
		return(-1);
	res = send_dmcpkt(GET_CALIBNUM_CMD,(char *)&dat,sizeof(dat));
	PRINT("get calib point num [%s] %d\n",drvname,res,0,0);
	if( res >= 2 && res <= 9 )
		return(res);
	return(2);
#else
	return(2);
#endif
}
int set_beep(int pen_down,int on)
{
int res;
unsigned long a;
#if USE_PIPE_COMM
u_short dat;
#endif
	if( dev == NULL )
		return(-1);
#if USE_PIPE_COMM
	if( pen_down )
		dat = on ? BEEP_DOWN_ON : BEEP_DOWN_OFF;
	else
		dat = on ? BEEP_UP_ON : BEEP_UP_OFF;
	res = send_dmcpkt(SET_BEEP_CMD,(char *)&dat,sizeof(dat));
	PRINT("set_beep [%s] res=%d \n",drvname,res,0,0);
	return(res);
#else
	if( pen_down )
		a = on ? BEEP_ON_DOWN_CMD : BEEP_OFF_DOWN_CMD;
	else
		a = on ? BEEP_ON_UP_CMD : BEEP_OFF_UP_CMD;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("set_beep [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return( (res == 0 ? 0 : -1) );
#endif
}
int get_beep()
{
#if USE_PIPE_COMM
int res;
u_short dat;
	if( dev == NULL )
		return(-1);
	res = send_dmcpkt(GET_BEEP_CMD,(char *)&dat,sizeof(dat));
	PRINT("get beep [%s] %d\n",drvname,res,0,0);
	if( res >= 0x00 && res <= 0x03 )
		return(res);
	return(-1);
#else
	return(0x03);
#endif
}
int save_exec()
{
#if USE_PIPE_COMM
int res;
u_short dat;
	if( dev == NULL )
		return(-1);
	res = send_dmcpkt(SAVE_CMD,(char *)&dat,sizeof(dat));
	PRINT("set_save [%s] res=%d \n",drvname,res,0,0);
	return(res);
#else
	return(0);
#endif
}
int set_next_calib()
{
int res;
unsigned long a;
#if USE_PIPE_COMM
u_short dat;
#endif
	if( dev == NULL )
		return(-1);
#if USE_PIPE_COMM
	dat = 0;
	res = send_dmcpkt(CALIB_NEXT_CMD,(char *)&dat,sizeof(dat));
	PRINT("set_next_calib [%s] res=%d \n",drvname,res,0,0);
	return(res);
#else
	a = CALIB_NEXT_CMD;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("set_next_calib [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return( (res == 0 ? 0 : -1) );
#endif
}
int set_end_calib()
{
int res;
unsigned long a;
#if USE_PIPE_COMM
u_short dat;
#endif
	if( dev == NULL )
		return(-1);
#if USE_PIPE_COMM
	dat = 0;
	res = send_dmcpkt(CALIB_END_CMD,(char *)&dat,sizeof(dat));
	PRINT("set_end_calib [%s] res=%d \n",drvname,res,0,0);
	return(res);
#else
	a = CALIB_END_CMD;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("set_end_calib [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return( (res == 0 ? 0 : -1) );
#endif
}
int cancel_calib()
{
int res;
unsigned long a;
#if USE_PIPE_COMM
u_short dat;
#endif
	if( dev == NULL )
		return(-1);
#if USE_PIPE_COMM
	dat = 0;
	res = send_dmcpkt(CALIB_CANCEL_CMD,(char *)&dat,sizeof(dat));
	PRINT("cancel_calib [%s] res=%d \n",drvname,res,0,0);
	return(res);
#else
	a = CALIB_CANCEL_CMD;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("cancel_calib [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return( (res == 0 ? 0 : -1) );
#endif
}
int ok_calib()
{
int res;
unsigned long a;
#if USE_PIPE_COMM
u_short dat;
#endif
	if( dev == NULL )
		return(-1);
#if USE_PIPE_COMM
	dat = 0;
	res = send_dmcpkt(CALIB_OK_CMD,(char *)&dat,sizeof(dat));
	PRINT("ok_calib [%s] res=%d \n",drvname,res,0,0);
	return(res);
#else
	a = CALIB_OK_CMD;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("ok_calib [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return( (res == 0 ? 0 : -1) );
#endif
}
int set_start_calib(uRect adj[],int count)
{
int res,i,n;
unsigned long a;
#if USE_PIPE_COMM
dmc_pktcalib pkt;
#endif
	PRINT("set_start_calib : XSetDeviceMode -> SwitchMode\n",0,0,0,0);
	if( dev == NULL )
		return(-1);
	if( count > 9 || count < 2 )
		return(-1);
#if USE_PIPE_COMM
	pkt.calib_point = count;
	memcpy(&pkt.adj,adj,sizeof(pkt.adj));
	res = send_dmcpkt(CALIB_FIRST_CMD,(char *)&pkt.calib_point
					,sizeof(dmc_pktcalib)-sizeof(dmc_pktheader));
	PRINT("set_start_calib [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return(res);
#else
	a = CALIB_PRE_FIRST_CMD;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("set_start_calib [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	for( i=0 ; i < count ; i++ )
	{
		a = CALIB_ADJ_DAT_CMD + i;
		res = XSetDeviceMode(gDisp,dev,a);
		PRINT("set_start_calib [%s] res=%d cmd=$%x \n",drvname,res,a,0);
		do_set_calib(0);	// raw x
		do_set_calib(0);	// raw y
		do_set_calib((u_short)adj[i].x);
		do_set_calib((u_short)adj[i].y);
	}
	a = CALIB_FIRST_CMD;
	res = XSetDeviceMode(gDisp,dev,a);
	PRINT("set_start_calib [%s] res=%d cmd=$%x \n",drvname,res,a,0);
	return( (res == 0 ? 0 : -1) );
#endif
}
#if !defined(USE_PIPE_COMM)
static int do_set_calib(u_short dat)
{
int n,res;
u_char a;
	for( n=12 ; n >= 0 ; n-=4 )
	{
		a = CALIB_1_DAT | ((dat >> n) & 0x0f);
		res = XSetDeviceMode(gDisp,dev,a);
		//PRINT("set mode [%s] res=%d dat=$%x \n",drvname,res,a,0);
	}
	return(0);
}
#endif
static XDeviceInfo *find_device_info(Display *display,char *name, Bool only_extended)
{
XDeviceInfo *devices;
int     loop;
int     num_devices;
int     len = strlen(name);
Bool    is_id = True;
XID     id;
    for( loop=0 ; loop < len; loop++ ) 
	{
	    if( !isdigit(name[loop]) ) 
		{
	        is_id = False;
	        break;
	    }
	}
	if( is_id ) 
	    id = atoi(name);
    devices = XListInputDevices(display, &num_devices);
    for( loop=0 ; loop < num_devices ; loop++ ) 
	{
	    if( (!only_extended || (devices[loop].use == IsXExtensionDevice))
		 && ((!is_id && strcmp(devices[loop].name, name) == 0)
								|| (is_id && devices[loop].id == id)))
		{
	        return &devices[loop];
	    }
    }
    return NULL;
}
#if USE_PIPE_COMM

static int pipe_open(char *name)
{
int fd,flg;
	flg = O_RDWR;
	if( (fd = open(name,flg)) == -1 )
	{
		mkfifo(name,0666);
		fd = open(name,flg);
	}
	return(fd);
}
static int send_dmcpkt(int cmd,char *dat,int size)
{
int res;
dmc_pkt pkt;
	pkt.u.pnorm.hd.cmd = cmd;
	switch( pkt.u.pnorm.hd.cmd )
	{
	case	CALIB_FIRST_CMD:
		memcpy(&pkt.u.pcalib.calib_point,dat,size);
		break;
	default:
		memcpy(&pkt.u.pnorm.dat,dat,size);
		break;
	}
	write(poutfd,&pkt,sizeof(dmc_pktheader)+size);
//printf("DEBUG:write pout(%d) cmd=%d siz=%d\n",poutfd,pkt.u.pnorm.hd.cmd,size);
	if( (res = XSetDeviceMode(gDisp,dev,XDEV_KICK)) == 0 )
	{
		res = recv_dmcpkt(cmd);
	}
	else
		res = -1;
	return(res);
}
static int recv_dmcpkt(int cmd)
{
dmc_pktres pres;
	if( read(pinfd,&pres,sizeof(dmc_pktres)) != sizeof(dmc_pktres) )
		return(-1);
//printf("DEBUG:read pin %d cmd=%d:%d res=%d\n",pinfd,pres.hd.cmd,cmd,pres.res);
	if( pres.hd.cmd = cmd )
		return( pres.res );
	return(-1);
}
#endif

