#ifndef __USBDMC_H__
#define __USBDMC_H__

/* IOCTL */
#define USBDMC_SETUP			1
#define USBDMC_RESET			2
#define USBDMC_SPECIFY			3
#define USBDMC_GOTO_IDLE		4
#define USBDMC_GOTO_XYP			5
#define USBDMC_READ_EEPROM		6
#define USBDMC_WRITE_EEPROM		7
#define USBDMC_READ_STAT		8

#endif
