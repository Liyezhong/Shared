#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include "usbdmc.h"

#if 1
#define	DEVNAME		"/dev/touch0"
#else
#if KER26
#define	DEVNAME		"/dev/dmc0"
#else
#define	DEVNAME		"/dev/usb/dmc0"
#endif
#endif

typedef int Bool;
#define	true	1
#define	false	0

typedef struct Pkt_Calib 
{
	unsigned short rawx,rawy;
	unsigned short refx,refy;
} Pkt_Calib;

typedef struct Pkt_W_EEPROM 
{
	unsigned char x;
	unsigned char y;
	Pkt_Calib x00;	// +---------------+
	Pkt_Calib x01;	// | x00  x01  x02 |
	Pkt_Calib x02;	// | x10  x11  x12 |
	Pkt_Calib x10;	// | x20  x21  x22 |
	Pkt_Calib x11;	// +---------------+
	Pkt_Calib x12;
	Pkt_Calib x20;
	Pkt_Calib x21;
	Pkt_Calib x22;
	unsigned short max_x;
	unsigned short max_y;
} Pkt_W_EEPROM;

typedef struct Pkt_R_EEPROM 
{
	unsigned char x;
	unsigned char y;
	Pkt_Calib x00;	// +---------------+
	Pkt_Calib x01;	// | x00  x01  x02 |
	Pkt_Calib x02;	// | x10  x11  x12 |
	Pkt_Calib x03;	// | x20  x21  x22 |
	Pkt_Calib x04;	// +---------------+
	Pkt_Calib x10;
	Pkt_Calib x11;
	Pkt_Calib x12;
	Pkt_Calib x13;
	Pkt_Calib x14;
	Pkt_Calib x20;
	Pkt_Calib x21;
	Pkt_Calib x22;
	Pkt_Calib x23;
	Pkt_Calib x24;
	Pkt_Calib x30;
	Pkt_Calib x31;
	Pkt_Calib x32;
	Pkt_Calib x33;
	Pkt_Calib x34;
	Pkt_Calib x40;
	Pkt_Calib x41;
	Pkt_Calib x42;
	Pkt_Calib x43;
	Pkt_Calib x44;
	unsigned short max_x;
	unsigned short max_y;
} Pkt_R_EEPROM;
 
extern int errno;
u_short tb1[] = 
{
	0x0303,
	0x005a,0x00a0,0x0019,0x0019,
	0x01d3,0x00a0,0x0200,0x0019,
	0x034d,0x00a0,0x03e7,0x0019,
	0x005a,0x01df,0x0019,0x0200,
	0x01d3,0x01df,0x0200,0x0200,
	0x034d,0x01df,0x03e7,0x0200,
	0x005a,0x031f,0x0019,0x03e7,
	0x01d3,0x031f,0x0200,0x03e7,
	0x034d,0x031f,0x03e7,0x03e7,
	0x03ff,0x03ff 
};
u_short tb[] = 
{
	0x0303,
	0x005a,0x00a0,0x0019,0x0019,
	0x01d3,0x00a0,0x0280,0x0019,
	0x034d,0x00a0,0x04e7,0x0019,
	0x005a,0x01df,0x0019,0x0200,
	0x01d3,0x01df,0x0280,0x0200,
	0x034d,0x01df,0x04e7,0x0200,
	0x005a,0x031f,0x0019,0x03e7,
	0x01d3,0x031f,0x0280,0x03e7,
	0x034d,0x031f,0x04e7,0x03e7,
	0x0500,0x0400 
};
char *devname;

int main(int argc, char *argv[]);
void init(void);
void doinit(int fd);
void chg(u_char *dp);
void recv_raw(void);
void recv(void);
void recv1(void);
int io_rdy(int path);
void dump(char *s,int len);

Bool usb_rw_eeprom(Bool write_exec,int fd,int max_x,int max_y,char s[]);
void conv_pkt(char *s,int max_x,int max_y);

void int_handler(int num)
{
	printf("signal %d\n",num);
	exit(0);
}

static void help(void)
{
    fprintf(stderr,"Syntax: usbtest <n> {<devname>}\n");
    exit(0);
}
int main(int argc, char *argv[])
{
    if (argc < 2 )
		help();
	devname = argc >= 3 ? argv[2] : DEVNAME;
    signal(SIGINT, int_handler);
	setbuf(stdout,0);
	init();
	switch( atoi(argv[1]) )
	{
	case	1: recv_raw();			break;
	case	2: recv();				break;
	case	3: recv1();				break;
	}
	return(0);
}
void init(void)
{
int fd,rate,res;
u_short st;
u_char s[512];
    if( (fd = open(devname, O_RDWR)) == -1 )
	{
        printf("open error %d :%s\n",errno,devname);
        return;
	}
	doinit(fd);
	close(fd);
}
void doinit(int fd)
{
int rate,res;
u_short st;
u_char s[512];
	printf("reset\n");
    ioctl(fd, USBDMC_RESET, 0);
	sleep(1);
	rate = 1;
	printf("specify\n");
    if( ioctl(fd, USBDMC_SPECIFY, &rate) != -1 ) 
	{
		printf("goto xyp\n");
    	if( ioctl(fd, USBDMC_GOTO_XYP, 0) != -1 ) 
		{
			printf("ok\n");
    		ioctl(fd, USBDMC_READ_STAT, &st);
			printf("get status %x \n",st);
			ioctl(fd, USBDMC_GOTO_IDLE, 0);
            printf("goto idle\n");
			res = usb_rw_eeprom(false,fd,1280,1024,s);
			printf("read eeprom res %d\n",res);
		#if 0
			memcpy(s,tb,sizeof(tb));
			chg(s);
			res = usb_rw_eeprom(true,fd,1024,1024,s);
			printf("write eeprom res %d\n",res);
			res = usb_rw_eeprom(false,fd,1280,1024,s);
			printf("read eeprom res %d\n",res);
		#endif
			printf("goto xyp\n");
    		ioctl(fd, USBDMC_GOTO_XYP, 0);
		}
		else
			printf("error %d\n",errno);
    }
	else
		printf("error %d\n",errno);
}
void chg(u_char *dp)
{
int i,k;
u_char a,b,*pp;
	for( i=0,pp=(u_char *)tb ; i < sizeof(tb) ; i+=2 )
	{
		a = pp[i];
		b = pp[i+1];
		dp[i] = b;
		dp[i+1] = a;
	}
}
void recv_raw(void)
{
int fd, cnt,a;
char s[100];
unsigned char *p;
    fd = open(devname, O_RDWR);
    if (fd == -1) 
	{
        printf("open error %d :%s\n",errno,devname);
        return;
    }
    cnt = 0;
	p = (unsigned char *)s;
	while(1)
	{
		a = read(fd,s,1);
		if( a > 0 )
			printf("in %x\n",p[0]);
		
	}
	//printf("wait...\n");
	//scanf("%d",&a);
    close(fd);
}
void recv(void)
{
int fd, cnt,a,b;
char s[100];
unsigned char *p;
    if( (fd = open(devname, O_RDWR)) == -1 )
	{
        printf("open error %d :%s\n",errno,devname);
        return;
    }
	p = (unsigned char *)s;
	a = 0;
	while(1)
	{
		if( (b = read(fd,&s[a],5)) < 0 )
		{
			printf("read err %d\n",errno);
			continue;
		}
		if( b == 0 )
			continue;
		if( b == 1 && a == 0 && s[0] == 0x12 )
		{
			printf("..reinit start\n");
			doinit(fd);
			printf("..reinit end\n");
			continue;
		}
		if( (a += b) < 0 )
		{
			if( errno != -EAGAIN )
				break;
		}
		if( a >= 5 )
		{
			a = 0;
			printf("Touch %x %s (%4d,%4d)\n",p[0],(p[0]&1?"ON ":"OFF")
											,(p[2]<<8)+p[1]
											,(p[4]<<8)+p[3]);
		}
		
	}
    close(fd);
}
void recv1(void)
{
int fd, cnt,a,b;
char s[100];
unsigned char *p;
    if( (fd = open(devname, O_RDWR|O_NONBLOCK)) == -1 )
	{
        printf("open error %d :%s\n",errno,devname);
        return;
    }
	p = (unsigned char *)s;
	a = 0;
	while(1)
	{
		if( !io_rdy(fd) )
		{
			printf(".");
			continue;
		}
		if( (b = read(fd,&s[a],5)) < 0 )
		{
			if( errno != -EAGAIN )
				break;
		}
		if( b == 1 && a == 0 && s[0] == 0x12 )
		{
			printf("..reinit start\n");
			doinit(fd);
			printf("..reinit end\n");
			continue;
		}
		a+=b;
		if( a >= 5 )
		{
			a = 0;
			printf("Touch %x %s (%4d,%4d)\n",p[0],(p[0]&1?"ON ":"OFF")
											,(p[2]<<8)+p[1]
											,(p[4]<<8)+p[3]);
		}
		
	}
    close(fd);
}
int io_rdy(int path)
{
fd_set rfds;
struct timeval tv;
int ret;
    FD_ZERO(&rfds);
    FD_SET(path, &rfds);
    tv.tv_sec = 0;
    tv.tv_usec = 1000*1000;
    ret = select(path+1, &rfds, NULL, NULL, &tv);
if( ret == -1 )
printf("select err %d\n",errno);
    return( ret <= 0 ? 0 : 1 );
}

void dump(char *s,int len)
{
int i,k;
static int pt = 0;
unsigned char *p;
	p = (unsigned char *)s;
	printf("Address  :  0 1  2 3  4 5  6 7  8 9  A B  C D  E F 0123456789ABCDEF\n");
	printf("--------   ---- ---- ---- ---- ---- ---- ---- ---- ----------------\n");
	for( i=0 ; i < len ; )
	{
		printf("%08X : ",pt);
		for( k=0 ; k < 16 ; k++ )
		{
			if( (i+k) >= len )
				printf("  %s",(k%2==1?" ":""));
			else
				printf("%02x%s",p[i+k],(k%2==1?" ":""));
		}
		for( k=0 ; i < len && k < 16 ; k++,i++ )
		{
			printf("%c",(p[i]<' '||p[i]>=0x80?'.':p[i]));
		}
		printf("\n");
		pt += k;
	}
}

Bool usb_rw_eeprom(Bool write_exec,int fd,int max_x,int max_y,char s[])
{
u_short fx,mx,ex;
u_short fy,my,ey;
#define	CONV_DAT(a)	((a>>8)|(a<<8))
Pkt_W_EEPROM *wp;
Pkt_R_EEPROM *rp;
int cnt,i;
char ss[512];
	cnt = 2 + ((5 * 5) * 8) + 2 + 2;
	if( write_exec )
	{
		memcpy(ss,s,cnt);
		wp = (Pkt_W_EEPROM *)ss;
		fx = CONV_DAT(wp->x00.refx);
		ex = CONV_DAT(max_x-fx);
		fx = CONV_DAT(fx);
		mx = CONV_DAT(max_x/2);
		fy = CONV_DAT(wp->x00.refy);
		ey = CONV_DAT(max_y-fy);
		fy = CONV_DAT(fy);
		my = CONV_DAT(max_y/2);
		wp->x00.refx = fx; wp->x00.refy = fy;
		wp->x01.refx = mx; wp->x01.refy = fy;
		wp->x02.refx = ex; wp->x02.refy = fy;
		wp->x10.refx = fx; wp->x10.refy = my;
		wp->x11.refx = mx; wp->x11.refy = my;
		wp->x12.refx = ex; wp->x12.refy = my;
		wp->x20.refx = fx; wp->x20.refy = ey;
		wp->x21.refx = mx; wp->x21.refy = ey;
		wp->x22.refx = ex; wp->x22.refy = ey;
		wp->max_x = CONV_DAT(max_x-1);
		wp->max_y = CONV_DAT(max_y-1);
		printf("********** W ***********\n");
		dump((char *)ss,2+(8*25)+4);
		scanf("%d",&i);
		if( ioctl(fd,USBDMC_WRITE_EEPROM,ss) == -1 )
			return(false);
	}
	else
	{
		if( ioctl(fd,USBDMC_READ_EEPROM,ss) == -1 )
			return(false);
		rp = (Pkt_R_EEPROM *)ss;
		fx = CONV_DAT(rp->x00.refx);
		ex = CONV_DAT(max_x-fx);
		fx = CONV_DAT(fx);
		mx = CONV_DAT(max_x/2);
		fy = CONV_DAT(rp->x00.refy);
		ey = CONV_DAT(max_y-fy);
		fy = CONV_DAT(fy);
		my = CONV_DAT(max_y/2);
		rp->x00.refx = fx; rp->x00.refy = fy;
		rp->x01.refx = mx; rp->x01.refy = fy;
		rp->x02.refx = ex; rp->x02.refy = fy;
		rp->x10.refx = fx; rp->x10.refy = my;
		rp->x11.refx = mx; rp->x11.refy = my;
		rp->x12.refx = ex; rp->x12.refy = my;
		rp->x20.refx = fx; rp->x20.refy = ey;
		rp->x21.refx = mx; rp->x21.refy = ey;
		rp->x22.refx = ex; rp->x22.refy = ey;
		rp->max_x = CONV_DAT(max_x-1);
		rp->max_y = CONV_DAT(max_y-1);
		printf("********** R ***********\n");
		dump((char *)ss,2+(8*25)+4);
		//scanf("%d",&i);
		memcpy(s,ss,cnt);
	}
	return(true);
}
