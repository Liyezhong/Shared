/*
 *
 * Copyright (c) 2004  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
/*
 * EUC
 * tab=4
 */
#include <linux/kernel.h>
#include <linux/poll.h>
#include <linux/usb.h>
#include <linux/smp_lock.h>
#include <linux/init.h>
#include <linux/module.h>
#include "vers.h"
#include "usbdmc.h"

#define DEBUG_HON       0

#define USBDMC_MINOR    181     /* minor */
#define VID_USBDMC      0x0afa  /* vendor ID */
#define PID_USBDMC      0x03e8  /* product ID */

#define true    1
#define false   0

#define INI_2_IDLE      0x05
#define S_RATE          0x40
#define RESET           0x55
#define IDLE_2_XYP      0x31
#define XYP_2_IDLE      0x02
#define IDLE_2_RomRd    0x1d
#define IDLE_2_RomWr    0x0d
#define ACK             0x06
#define NAK             0x15

#define DRIVER_VERSION      "v0.1"
#define DRIVER_AUTHOR       "NW, based on something else"
#define DRIVER_DESC     "USB Touchscreen Driver DMC"

typedef struct
{
    int                 isopen;
    struct usb_device   *dev;               /* usb device data */
#if KER26
    struct urb          *irq;               /* URB for interrupt      */
#else
    struct urb          irq;                /* URB for interrupt      */
#endif
    wait_queue_head_t   wait;               /* wait queue for interrupt */
    wait_queue_head_t   remove_ok;   
    int probe_ok;   
#define PROBE_NONE      0
#define PROBE_AVAIL     0x12345678
    char                data[64];
    int                 rxputp;
    int                 rxgetp;
#define MAX_RXBUF   256
    char                rxbuf[MAX_RXBUF];   /* recv buffer */
    int                 ep_intr_in;         /* ENDPOINT(INT-IN)*/
    int                 ep_bulk_out;
    int                 ep_bulk_in;
    char                svd[5];
} usbdmc_data_t;

static usbdmc_data_t *g_usbdmc_data;

static void pktdump(char *title,int len,char *p);
static int usbdmc_setup(usbdmc_data_t* pdata);
static int usbdmc_reset(usbdmc_data_t* pdata);
static int usbdmc_specify(usbdmc_data_t* pdata,int rate);
static int usbdmc_goto_idle(usbdmc_data_t* pdata);
static int usbdmc_goto_xyp(usbdmc_data_t* pdata);
static int usbdmc_get_stat(usbdmc_data_t* pdata,u_short *stat);
static int usbdmc_read_eeprom(usbdmc_data_t* pdata,u_char *buf);
static int usbdmc_write_eeprom(usbdmc_data_t* pdata,u_char *buf);
static int usbdmc_open(struct inode *inode, struct file *file);
static int usbdmc_close(struct inode *inode, struct file *file);
static int usbdmc_ioctl(struct inode *inode, struct file *file,
               unsigned int cmd, unsigned long arg);
static ssize_t usbdmc_read(struct file * file, char * buffer, size_t count, loff_t *ppos);
static unsigned int usbdmc_poll(struct file *file, poll_table * wait);
#if KER26
static int usbdmc_probe(struct usb_interface *intface,const struct usb_device_id *id);
static void usbdmc_disconnect(struct usb_interface *intface);
#else
static void* usbdmc_probe(struct usb_device *dev, unsigned int ifnum,
                          const struct usb_device_id *id);
static void usbdmc_disconnect(struct usb_device *dev, void *ptr);
#endif

/*
 int usb_control_msg(struct usb_device *dev, unsigned int pipe,
                __u8 request, __u8 requesttype,
                __u16 value, __u16 index, void *data, __u16 size, int timeout)
 [sample]
    usb_control_msg(dev, usb_snddefctrl(dev), USB_REQ_SET_ADDRESS,
        0, dev->devnum, 0, NULL, 0, HZ * GET_TIMEOUT);
    usb_control_msg(dev, usb_rcvctrlpipe(dev, 0),
            USB_REQ_GET_DESCRIPTOR, USB_DIR_IN,
            (type << 8) + index, 0, buf, size, HZ * GET_TIMEOUT)
*/
static void pktdump(char *title,int len,char *p)
{
int i,k;
char s[256];
unsigned char *pp;
    k = sprintf(s,"%s : len=%d",title,len);
    if( len <= 0 )
        return;
    k += sprintf(&s[k]," data=");
    if( p )
    {
        for( pp=(unsigned char *)p,i=0 ; i < len ; i++ )
        {
            k += sprintf(&s[k],"$%02x ",pp[i]);
        }
    }
    printk(KERN_ERR "%s\n",s);
}
static int usbdmc_setup(usbdmc_data_t* pdata)
{
u_short st;
    /* usbdmc_reset(pdata); */
    usbdmc_specify(pdata,0);
    usbdmc_goto_xyp(pdata);
    usbdmc_get_stat(pdata,&st);
    return(true);
}
static int usbdmc_reset(usbdmc_data_t* pdata)
{
int res;
char bf[10];
    res = usb_control_msg(pdata->dev,usb_rcvctrlpipe(pdata->dev,0),RESET,0xc0,0,0,bf,2,HZ*120);
    pktdump("usbdmc_reset",res,bf);
    if( res > 0 && bf[0] == ACK )
        return(true);   // ACK goto init mode
    return(false);      // NAK
}
static int usbdmc_specify(usbdmc_data_t* pdata,int rate)
{
int res;
char bf[10];
    if( rate < 0 || rate > 5 )
        return(false);
    res = usb_control_msg(pdata->dev,usb_rcvctrlpipe(pdata->dev,0),INI_2_IDLE,0xc0,S_RATE+rate,0,bf,2,HZ*120);
    pktdump("usbdmc_specify",res,bf);
    //printk(KERN_ERR "rate=%d\n",rate);
    if( res > 0 && bf[0] == ACK )
        return(true);   // ACK goto idle mode
    return(false);      // NAK
}
static int usbdmc_goto_idle(usbdmc_data_t* pdata)
{
int res;
char bf[10];
    res = usb_control_msg(pdata->dev,usb_rcvctrlpipe(pdata->dev,0),XYP_2_IDLE,0xc0,0,0,bf,2,HZ*5);
    pktdump("usbdmc_goto_idle",res,bf);
    if( res > 0 && bf[0] == ACK )
        return(true);   // ACK goto xyp mode
    return(false);      // NAK
}
static int usbdmc_goto_xyp(usbdmc_data_t* pdata)
{
int res;
    res = usb_control_msg(pdata->dev,usb_sndctrlpipe(pdata->dev,0),IDLE_2_XYP,0x40,0,0,NULL,0,HZ*120);
    pktdump("usbdmc_goto_xyp",res,NULL);
    return(true);   // goto xyp mode
}
static int usbdmc_get_stat(usbdmc_data_t* pdata,u_short *stat)
{
int res;
u_char bf[10];
    printk(KERN_ERR "usbdmc_get_stat s\n");
    res = usb_control_msg(pdata->dev,usb_rcvctrlpipe(pdata->dev,0),0x15,0xc0,0,0,bf,2,HZ*10);
    pktdump("usbdmc_get_stat",res,bf);
    if( res <= 0 )
        return(false);
    *stat = (bf[0]<<8) + bf[1];
    return(true);
}
static int usbdmc_read_eeprom(usbdmc_data_t* pdata,u_char *bf)
{
int res,i,cnt,k;
u_short st;
    printk(KERN_ERR "usbdmc_read_eeprom\n");
    usbdmc_get_stat(pdata,&st);
    if( st & 0x0080 )
        return(-1);
    res = usb_control_msg(pdata->dev,usb_rcvctrlpipe(pdata->dev,0),IDLE_2_RomRd,0xc0,0,0,bf,2,HZ*120);
    //pktdump("usbdmc_read_eeprom",res,bf);
    if( res <= 0 )
        return(-1);
    cnt = (5*5)+1;
    for( k=2,i=0 ; i < (cnt-1) ; i++,k+=8 )
    {
        res = usb_control_msg(pdata->dev, usb_rcvctrlpipe(pdata->dev, 0),
                IDLE_2_RomRd, 0xc0, 0, 0, &bf[k], 8, HZ * 120);
        //pktdump("usbdmc_read_eeprom",res,&bf[k]);
    }
    res = usb_control_msg(pdata->dev, usb_rcvctrlpipe(pdata->dev, 0),
            IDLE_2_RomRd, 0xc0, 0, 0, &bf[k], 4, HZ * 120);
    //pktdump("usbdmc_read_eeprom",res,&bf[k]);
    k+=4;
    return(k);
}
static int usbdmc_write_eeprom(usbdmc_data_t* pdata,u_char *bf)
{
int i,res;
char s[20];
u_short *p,a;
    for( i=0,p=(u_short *)bf ; i < 39 ; i++ )
    {
        a = (p[i]>>8) | (p[i]<<8);
        //printk(KERN_ERR "usbdmc_write_eeprom %d $%03x(%4d) \n",i,a,a);
        res = usb_control_msg(pdata->dev,usb_rcvctrlpipe(pdata->dev,0)
                                ,IDLE_2_RomWr,0xc0,a,0,s,2,HZ*120);
        //pktdump("usbdmc_write_eeprom",res,s);
        if( s[0] != ACK )
            break;
    }
    //printk(KERN_ERR "WRITE %d\n",i);
    pktdump("usbdmc_write_eeprom",res,s);
    return( s[0] == ACK ? i : -1 );
}

#if KER26
static void usbdmc_irq(struct urb *urb, struct pt_regs *regs)
#else
static void usbdmc_irq(struct urb *urb)
#endif
{
int i,getp,putp;
usbdmc_data_t *p;
    #if DEBUG_HON
        printk(KERN_ERR "usbdmc_irq status %d\n",urb->status);
    #endif
    if( urb->status )
    {
#if KER26
        goto exit;
#else
        return;
#endif
    }
    p = urb->context;
    //pktdump(KERN_ERR "usbdmc_irq",5,p->data);
    getp = p->rxgetp;
    putp = p->rxputp;
    if( memcmp(p->svd,p->data,5) == 0 )
#if KER26
            goto exit;
#else
        return;
#endif
    memcpy(p->svd,p->data,5);
    for( i=0 ; i < 5 ; i++ )
    {
        p->rxbuf[putp++] = p->data[i];
        putp = putp >= MAX_RXBUF ? 0 : putp;    
        if( putp == getp )
#if KER26
            goto exit;
#else
            return;
#endif
    }
    p->rxputp = putp;
    wake_up_interruptible(&p->wait);
#if KER26
exit:
    p = urb->context;
    usb_submit_urb(p->irq,GFP_ATOMIC);
#endif
}

static int usbdmc_open(struct inode *inode, struct file *file)
{
    usbdmc_data_t *pdata;
    pdata = g_usbdmc_data;

//printk("usbdmc_open 1\n");
    if( pdata == NULL )
    {
    #if KER26
        printk(KERN_ERR "usbdmc_open $%x\n",pdata);
    #endif
        return -ENODEV;
    }
    if( g_usbdmc_data->probe_ok != PROBE_AVAIL )
    {
        return -EBUSY;
    }
#if DEBUG_HON
    printk(KERN_ERR "usbdmc_open $%x\n",pdata);
#endif
    if( pdata->isopen )
    {
        return -EBUSY;
    }
//printk("usbdmc_open 2\n");
    init_waitqueue_head(&pdata->wait);
    init_waitqueue_head(&pdata->remove_ok);
    file->private_data = pdata;
    pdata->isopen = 1;
    pdata->rxputp = 0;
    pdata->rxgetp = 0;
//printk("usbdmc_open 3\n");
#if KER26
    pdata->irq->dev = pdata->dev;
    usb_submit_urb(pdata->irq,GFP_KERNEL);
#else
    pdata->irq.dev = pdata->dev;
    usb_submit_urb(&pdata->irq);
#endif
#if DEBUG_HON
    printk("usbdmc_open end\n");
#endif
    return 0;
}

static int usbdmc_close(struct inode *inode, struct file *file)
{
    usbdmc_data_t* pdata;
    pdata = g_usbdmc_data;
#if DEBUG_HON
    printk(KERN_ERR "usbdmc_close $%x\n",pdata);
#endif
    if( pdata == NULL )
        return 0;
    if( pdata->isopen )
    {
        pdata->isopen = 0;
#if KER26
        //usb_unlink_urb(pdata->irq);
        usb_kill_urb(pdata->irq);
#else
        usb_unlink_urb(&pdata->irq);
#endif
        //pdata->irq = NULL;
        wake_up(&pdata->remove_ok);
    }
#if DEBUG_HON
    printk("usbdmc_close end\n");
#endif
    return 0;
}

static int usbdmc_ioctl(struct inode *inode, struct file *file,
               unsigned int cmd, unsigned long arg)
{
usbdmc_data_t* pdata;
int res,a;
u_short b;
char buf[512];
    #if DEBUG_HON
        printk(KERN_ERR "usbdmc_ioctl %d($%x)\n",cmd,cmd);
    #endif
    res = true;
    pdata = file->private_data;
    if( pdata->dev == NULL )
        return(-ENOTCONN);
    switch(cmd)
    {
    case USBDMC_RESET:
        res = usbdmc_reset(pdata);
        break;
    case USBDMC_SPECIFY:
        get_user(a,(int *)arg);
        res = usbdmc_specify(pdata,a);
        break;
    case USBDMC_GOTO_XYP:
        res = usbdmc_goto_xyp(pdata);
        break;
    case USBDMC_GOTO_IDLE:
        res = usbdmc_goto_idle(pdata);
        break;
    case USBDMC_SETUP:
        res = usbdmc_setup(pdata);
        break;
    case USBDMC_READ_EEPROM:
        if( (res = usbdmc_read_eeprom(pdata,buf)) != -1 )
        {
            res = copy_to_user((char *)arg,(char *)buf,res);
            res = true;
        }
        else
            res = false;
        break;
    case USBDMC_WRITE_EEPROM:
        res = copy_from_user((char *)buf,(char *)arg,39*2);
        res = usbdmc_write_eeprom(pdata,buf) != -1 ? true : false;
        break;
    case USBDMC_READ_STAT:
        res = usbdmc_get_stat(pdata,&b);
        put_user(b,(u_short *)arg);
        break;
    default:
        return(-ENOIOCTLCMD);
    }
    if( !res )
        return(-EIO);
    return(0);
}

static ssize_t usbdmc_read(struct file * file, char * buffer, size_t count, loff_t *ppos)
{
int i,getp,putp;
usbdmc_data_t *p;
    #if DEBUG_HON
        printk(KERN_ERR "usbdmc_read entry size %d\n",count);
    #endif
    p = file->private_data;
    if( p->dev == NULL )
    {
        printk(KERN_ERR "usbdmc_read dev-null\n");
        return(-ENOTCONN);
    }
    getp = p->rxgetp;
    for( i=0 ; i < count ; )
    {
        putp = p->rxputp;
        if( getp == putp )
        {
            if( file->f_flags & O_NONBLOCK )
            {
                //printk(KERN_ERR "usbdmc_read non-block\n");
                if( i > 0 )
                    break;
                return(-EAGAIN);
            }
            //printk(KERN_ERR "usbdmc_read irq wait...\n");
#if KER26
            wait_event_interruptible(p->wait,getp!=p->rxputp);
#else
            interruptible_sleep_on(&p->wait);
#endif
            //printk(KERN_ERR "usbdmc_read irq wake\n");
            p = file->private_data;
            if( p->dev == NULL )
            {
                printk(KERN_ERR "usbdmc_read dev-null\n");
                return(-ENOTCONN);
            }
            //printk(KERN_ERR "usbdmc_read irq wakeup\n");
            if( signal_pending(current) )
                return(-EINTR);
        }
        //printk(KERN_ERR "usbdmc_read data %x\n",p->rxbuf[getp]);
        put_user(p->rxbuf[getp++],&buffer[i]);
        getp = getp >= MAX_RXBUF ? 0 : getp;
        i++;
    }
    p->rxgetp = getp;
    #if DEBUG_HON
        printk(KERN_ERR "usbdmc_read exit %d \n",i);
    #endif
    return(i);
}

static unsigned int usbdmc_poll(struct file *file, poll_table * wwait)
{
usbdmc_data_t *p;
    #if DEBUG_HON
        printk(KERN_ERR "usbdmc_poll\n");
    #endif
    p = file->private_data;
    poll_wait(file,&p->wait,wwait);
    p = file->private_data;
    if( p->dev == NULL )
    {
    #if DEBUG_HON
        printk(KERN_ERR "usbdmc_poll dev-null\n");
    #endif
        return(-ENOTCONN);
    }
    if( p->rxgetp != p->rxputp )
        return(POLLIN|POLLRDNORM);
    return(0);
}

#if KER26
static struct file_operations usbdmc_fileopes = {
#if 0
    .owner=     THIS_MODULE,
#endif
    .read=      usbdmc_read,
    .open=      usbdmc_open,
    .release=   usbdmc_close,
    .ioctl=   usbdmc_ioctl,
    .poll=   usbdmc_poll,
};
static struct usb_class_driver usbdmc_class = {
    .name =     "usb/dmc%d",
    .fops =     &usbdmc_fileopes,
#if 0
    .mode =     S_IFCHR | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH,
#endif
    .minor_base =   USBDMC_MINOR,
};
#else
static struct file_operations usbdmc_fileopes = 
{
    owner:          THIS_MODULE,
    ioctl:          usbdmc_ioctl,
    open:           usbdmc_open,
    read:           usbdmc_read,
    poll:           usbdmc_poll,
    release:        usbdmc_close,
};
#endif

#if KER26
static int usbdmc_probe(struct usb_interface *intface,const struct usb_device_id *id)
{
    struct usb_device *dev = NULL;
    struct usb_host_interface *iface_desc;
    struct usb_endpoint_descriptor *endpoint;
    unsigned int pipe;
    int n, intr_interval, len;

    dev = usb_get_dev(interface_to_usbdev(intface));
    printk(KERN_ERR "DMC USB-Driver %s\n",TBUSB_VERSION);
    printk(KERN_ERR "usbdmc_probe vendor=$%x product=$%x\n"
                    ,dev->descriptor.idVendor
                    ,dev->descriptor.idProduct
                    );
    if( dev->descriptor.idVendor != VID_USBDMC )
    {
        printk(KERN_INFO "USBDMC: unknown vendor id.\n");
        return -ENODEV;
    }
    if( g_usbdmc_data )
    {
        printk(KERN_INFO "USBDMC: no more probe.\n");
        return -EIO;
    }
    iface_desc = intface->cur_altsetting;
    if( (g_usbdmc_data = kmalloc(sizeof(usbdmc_data_t), GFP_KERNEL)) == NULL )
    {
        printk(KERN_INFO "no memory\n");
        return -EIO;
    }
    memset(g_usbdmc_data,0,sizeof(usbdmc_data_t));

    if( (g_usbdmc_data->irq  = usb_alloc_urb(0, GFP_KERNEL)) == NULL )
    {
        printk(KERN_INFO "no memory\n");
        return -EIO;
    }
    //memset(g_usbdmc_data->irq,0,sizeof(struct urb));

    intr_interval = 0;
    g_usbdmc_data->ep_intr_in  = -1;
    g_usbdmc_data->ep_bulk_out = -1;
    g_usbdmc_data->ep_bulk_in  = -1;
    for(n = 0; n < iface_desc->desc.bNumEndpoints; n++)
    {
        endpoint = &iface_desc->endpoint[n].desc;
        switch(endpoint->bEndpointAddress&USB_ENDPOINT_NUMBER_MASK)
        {
        case 1: /* INT-IN */
            if( ! (endpoint->bEndpointAddress&USB_ENDPOINT_DIR_MASK) )
                break;
            if( (endpoint->bmAttributes&USB_ENDPOINT_XFERTYPE_MASK) == USB_ENDPOINT_XFER_INT )
            {
                g_usbdmc_data->ep_intr_in = 1;
                intr_interval = endpoint->bInterval;
                printk("usbdmc_probe: endpoint irq-in 1 ,interval=%d\n",intr_interval);
            }
            break;
        }
    }
    if( g_usbdmc_data->ep_intr_in == -1 )
    {
        printk("endpoint error!!\n");
        return -EIO;
    }
    g_usbdmc_data->dev    = dev;
    g_usbdmc_data->isopen = 0;
    g_usbdmc_data->rxputp = 0;
    g_usbdmc_data->rxgetp = 0;

    usb_set_intfdata(intface,g_usbdmc_data);
    if( usb_register_dev(intface,&usbdmc_class) )
    {
        usb_set_intfdata(intface,NULL);
        printk("regster error!!\n");
        return -EIO;
    }

    pipe = usb_rcvintpipe(g_usbdmc_data->dev, g_usbdmc_data->ep_intr_in);
    len  = usb_maxpacket(dev, pipe, usb_pipeout(pipe));
    //printk("usb_packet len=%d!!\n",len);
    usb_fill_int_urb(g_usbdmc_data->irq,
                 dev, pipe, g_usbdmc_data->data, len,
                 usbdmc_irq, g_usbdmc_data, intr_interval);
    g_usbdmc_data->irq->transfer_flags = 0;//URB_ISO_ASAP;
    g_usbdmc_data->probe_ok = PROBE_AVAIL;
    return 0;
}

static void usbdmc_disconnect(struct usb_interface *intface)
{
    printk(KERN_ERR "usbdmc_disconnect\n");
    if( g_usbdmc_data )
    {
        if( g_usbdmc_data->isopen )
        {
            g_usbdmc_data->rxputp = g_usbdmc_data->rxputp+1 >= MAX_RXBUF 
                    ? 0 : g_usbdmc_data->rxputp+1;  
            g_usbdmc_data->dev = NULL;
            wake_up_interruptible(&g_usbdmc_data->wait);
            wait_event(g_usbdmc_data->remove_ok,g_usbdmc_data->isopen==0);
            //printk(KERN_ERR "usbdmc_disconnect 1\n");
        }
        if( g_usbdmc_data->irq ) 
            usb_free_urb(g_usbdmc_data->irq);
        usb_deregister_dev(intface,&usbdmc_class);
        kfree(g_usbdmc_data);
        g_usbdmc_data = NULL;
    }
    //printk(KERN_ERR "usbdmc_disconnect e\n");
}

#else   // else of KER26
static void* usbdmc_probe(struct usb_device *dev, unsigned int ifnum,
                          const struct usb_device_id *id)
{
    struct usb_interface_descriptor *inf;
    struct usb_config_descriptor    *config;
    unsigned int pipe;
    int n, intr_interval, len;

    printk(KERN_ERR "DMC USB-Driver %s\n",TBUSB_VERSION);
    printk(KERN_ERR "usbdmc_probe ifnum=$%x vendor=$%x product=$%x\n"
                    ,ifnum
                    ,dev->descriptor.idVendor
                    ,dev->descriptor.idProduct
                    );
    if( dev->descriptor.idVendor != VID_USBDMC )
    {
        printk(KERN_INFO "USBDMC: unknown vendor id.\n");
        return NULL;
    }
    if( g_usbdmc_data )
    {
        printk(KERN_INFO "USBDMC: no more probe.\n");
        return NULL;
    }
    config = dev->actconfig;
    inf    = &config->interface[ifnum].altsetting[0];
    if( (g_usbdmc_data = kmalloc(sizeof(usbdmc_data_t), GFP_KERNEL)) == NULL )
    {
        printk(KERN_INFO "no memory\n");
        return NULL;
    }
    memset(g_usbdmc_data,0,sizeof(usbdmc_data_t));

    intr_interval = 0;
    g_usbdmc_data->ep_intr_in  = -1;
    g_usbdmc_data->ep_bulk_out = -1;
    g_usbdmc_data->ep_bulk_in  = -1;
//printk("usbdmc_probe 1\n");
    for(n = 0; n < inf->bNumEndpoints; n++)
    {
        switch(inf->endpoint[n].bEndpointAddress&USB_ENDPOINT_NUMBER_MASK)
        {
        case 1: /* INT-IN */
            if( ! (inf->endpoint[n].bEndpointAddress&USB_ENDPOINT_DIR_MASK) )
                break;
            if( (inf->endpoint[n].bmAttributes&USB_ENDPOINT_XFERTYPE_MASK) == USB_ENDPOINT_XFER_INT )
            {
                g_usbdmc_data->ep_intr_in = 1;
                intr_interval = inf->endpoint[n].bInterval;
                printk("usbdmc_probe: endpoint irq-in 1 ,interval=%d\n",intr_interval);
            }
            break;
        }
    }
//printk("usbdmc_probe 2\n");
    if( g_usbdmc_data->ep_intr_in == -1 )
    {
        printk("endpoint error!!\n");
        return NULL;
    }
    g_usbdmc_data->dev    = dev;
    g_usbdmc_data->isopen = 0;
    g_usbdmc_data->rxputp = 0;
    g_usbdmc_data->rxgetp = 0;
//printk("usbdmc_probe 3\n");

    pipe = usb_rcvintpipe(g_usbdmc_data->dev, g_usbdmc_data->ep_intr_in);
    len  = usb_maxpacket(dev, pipe, usb_pipeout(pipe));
    usb_set_idle(dev, inf->bInterfaceNumber, 0, 0);
    FILL_INT_URB(&g_usbdmc_data->irq,
                 dev, pipe, g_usbdmc_data->data, len,
                 usbdmc_irq, g_usbdmc_data, intr_interval);
#if DEBUG_HON
    printk("usbdmc_probe end\n");
#endif
    g_usbdmc_data->probe_ok = PROBE_AVAIL;
    return g_usbdmc_data;
}

static void usbdmc_disconnect(struct usb_device *dev, void *ptr)
{
    printk(KERN_ERR "usbdmc_disconnect\n");
    if( g_usbdmc_data )
    {
        if( g_usbdmc_data->isopen )
        {
            g_usbdmc_data->dev = NULL;
            wake_up_interruptible(&g_usbdmc_data->wait);
            sleep_on(&g_usbdmc_data->remove_ok);
            //printk(KERN_ERR "usbdmc_disconnect 1\n");
        }
        g_usbdmc_data->probe_ok = PROBE_NONE;
        kfree(g_usbdmc_data);
        g_usbdmc_data = NULL;
    }
#if DEBUG_HON
    printk(KERN_ERR "usbdmc_disconnect e\n");
#endif
}
#endif  // end of KER26

static struct usb_device_id usbdmc_table [] = 
{
        { USB_DEVICE(VID_USBDMC, PID_USBDMC) },
        { }
};
MODULE_DEVICE_TABLE (usb, usbdmc_table);

#if KER26
static struct usb_driver usbdmc_data = {
#if 0
    .owner =        THIS_MODULE,
#endif
    .name =         "usbdmc",
    .probe =        usbdmc_probe,
    .disconnect =   usbdmc_disconnect,
    .id_table =     usbdmc_table,
};
#else
static struct usb_driver usbdmc_data = 
{
    name:       "usbdmc",
    probe:      usbdmc_probe,
    disconnect: usbdmc_disconnect,
    fops:       &usbdmc_fileopes,
    minor:      USBDMC_MINOR,
    id_table:   usbdmc_table,
};
#endif

int __init usbdmc_init(void)
{
    printk(KERN_ERR "usbdmc_init\n");
    if (usb_register(&usbdmc_data) < 0) 
    {
        return -1;
    }
    return 0;
}

void __exit usbdmc_exit(void)
{
    printk(KERN_ERR "usbdmc_exit\n");
    usb_deregister(&usbdmc_data);
}

module_init(usbdmc_init);
module_exit(usbdmc_exit);

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE("GPL");
