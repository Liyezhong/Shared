/*
 *
 * Copyright (c) 2007  DMC Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 * Except as contained in this notice, the name of the DMC Co., Ltd shall not 
 * be used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from DMC Co., Ltd.
 */
/*
 * EUC
 * tab=4
 */
#if KER26
#define __KERNEL__	1
#if 0
#include <linux/config.h>
#endif
#include <linux/module.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/interrupt.h>
#include <linux/ioport.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/pci.h>
#include <linux/pnp.h>
#include <linux/sysctl.h>
#include <linux/poll.h>
#include <asm/io.h>
#if 0
#include <asm/dma.h>
#include <asm/uaccess.h>
#include <asm/unistd.h>
#endif
#else
#include <linux/module.h>
#include <linux/kernel.h> // printk
//#include <linux/sched.h> // current->com, current->pid
#include <asm/io.h> // inb,outb
#include <linux/init.h> // module_init,module_exit
#include <asm/uaccess.h> //  copy_to_user, copy_from_user
#include <linux/ioport.h> // check_region,release_region
#include <linux/errno.h>
#include <linux/delay.h>
#include <linux/time.h>
#include <linux/poll.h>
#endif

#include "usbdmc.h"
#include "vers.h"

#if 0
#define DEBUG_FUNC_ENTRY
#define DEBUG_HONDA1
#endif

#define	DEVICE_NAME				"tpdmc"
static char *tpdmc_version 		= FILTERUSB_VERSION;
#if KER26
static const char *RAW_DEVICE 	= "/dev/dmc0";
#else
static const char *RAW_DEVICE 	= "/dev/usb/dmc0";
#endif
typedef struct tpdmc
{
	int noblk_mode;
	int is_open;
	struct file *fd;
	int reinit_req;
} tpdmcrec;

static tpdmcrec *rawdev = NULL;
static int tpdmc_major  = 200;

static int tpdmc_open(struct inode *inode, struct file *file);
static int tpdmc_close(struct inode *inode, struct file *file);
static int tpdmc_ioctl(struct inode *inode, struct file *file,
               unsigned int cmd, unsigned long arg);
static ssize_t tpdmc_read(struct file * file, char * buffer, size_t count, loff_t *ppos);
static unsigned int tpdmc_poll(struct file *file, poll_table * wwait);
static void tpdmc_term(void);
static int tpdmc_init(void);
static int tpdmc_rawdevopen(int first);
static void tpcdmc_rawdevclose(void);

#define	open(a,b,c)		filp_open(a,b,c)
#define	close(a)		filp_close(a,0)
#define	read(a,b,c,d)	a->f_op->read(a,b,c,d)
#define	poll(a,b)		a->f_op->poll(a,b)
#define	ioctl(a,b,c)	a->f_op->ioctl(a->f_dentry->d_inode,a,b,c)

/************************************************************************
 * open
 */
static int tpdmc_open(struct inode *inode, struct file *pfile)
{
int res;
	//MOD_INC_USE_COUNT;
#if defined(DEBUG_FUNC_ENTRY)
	printk(KERN_INFO "tpdmc_open entry\n");
#endif
	rawdev->noblk_mode = pfile->f_flags & O_NONBLOCK ? 1 : 0;
	res = tpdmc_rawdevopen(1);
	rawdev->is_open = 1;
	rawdev->reinit_req = 0;
	return(0);
}
static int tpdmc_rawdevopen(int first)
{
struct file *fd;
int md;
	md = rawdev->noblk_mode ? O_NONBLOCK : 0;
	fd = open(RAW_DEVICE,O_RDWR|md,0600);
	if( IS_ERR(fd) || fd == NULL )
	{
		if( first )
			printk(KERN_INFO  "tpdmc_open/(%s) err $%x\n",RAW_DEVICE,(int)fd);
		return(-1);
	}
	rawdev->fd = fd;
	//printk(KERN_INFO  "tpdmc_rawdevopen/ok $%x \n",(int)rawdev->fd);
	return(0);
}
/************************************************************************
 * close
 */
static int tpdmc_close(struct inode *inode, struct file *pfile)
{
	//MOD_DEC_USE_COUNT;
#if defined(DEBUG_FUNC_ENTRY)
	printk("tpdmc_close entry\n");
#endif
	tpcdmc_rawdevclose();
	rawdev->is_open = 0;
	return(0);
}
static void tpcdmc_rawdevclose(void)
{
#if defined(DEBUG_FUNC_ENTRY)
	printk(KERN_INFO "tpdmc_rawdevclose entry %d %x\n",rawdev->is_open,rawdev->fd);
#endif
	if( rawdev->fd )
	{
		close(rawdev->fd);
		rawdev->fd = NULL;
	}
	//printk(KERN_INFO "tpdmc_rawdevclose ok\n");
}
/************************************************************************
 * read
 */
static ssize_t tpdmc_read(struct file *pfile, char *cbuff, size_t size, loff_t *ppos)
{
int res;
#if 0	//defined(DEBUG_FUNC_ENTRY)
	printk("tpdmc_read entry\n");
#endif
	if( rawdev->fd == NULL )
	{
		if( tpdmc_rawdevopen(0) != 0 )
			return(0);
		rawdev->reinit_req = 1;
		//printk("tpdmc_read reinit ok\n");
	}
	if( rawdev->reinit_req )
	{
		rawdev->reinit_req = 0;
		cbuff[0] = 0x12;
		return(1);
	}
	res = read(rawdev->fd,cbuff,size,ppos);
	//if( res != -EAGAIN )
	//	printk("tpdmc_read %d\n",res);
	if( res < 0 )
	{
		if( res != -EAGAIN )
			tpcdmc_rawdevclose();
		res = 0;
	}
	return(res);
}
/************************************************************************
 * poll
 */
static u_int tpdmc_poll(struct file *file, poll_table * wwait)
{
int res;
	//printk(KERN_INFO  "tpdmc_poll\n");
	if( rawdev->fd == NULL )
	{
		if( tpdmc_rawdevopen(0) != 0 )
			return(0);
		rawdev->reinit_req = 1;
		return(POLLIN|POLLRDNORM);
	}
	res = poll(rawdev->fd,wwait);
	if( res < 0 )
	{
		//printk(KERN_INFO  "tpdmc_poll res=%x\n",res);
		tpcdmc_rawdevclose();
		res = 0;
	}
	return(res);
}
/************************************************************************
 * ioctl
 */
static int tpdmc_ioctl(struct inode *inode, struct file*pfile, unsigned int cmd, unsigned long arg)
{
int res;
#if defined(DEBUG_FUNC_ENTRY)
	printk("tpdmc_ioctl entry. cmd=%d \n",cmd);
#endif
	if( rawdev->fd == NULL )
	{
		if( tpdmc_rawdevopen(0) != 0 )
			return(-ENOTCONN);
	}
    switch(cmd)
	{
    case USBDMC_RESET:
		res = ioctl(rawdev->fd,USBDMC_RESET,0);
		break;
    case USBDMC_SPECIFY:
		res = ioctl(rawdev->fd,USBDMC_SPECIFY,(u_long)arg);
		break;
    case USBDMC_GOTO_XYP:
		res = ioctl(rawdev->fd,USBDMC_GOTO_XYP,0);
		break;
    case USBDMC_GOTO_IDLE:
		res = ioctl(rawdev->fd,USBDMC_GOTO_IDLE,0);
		break;
    case USBDMC_SETUP:
		res = ioctl(rawdev->fd,USBDMC_SETUP,0);
		break;
    case USBDMC_READ_EEPROM:
		res = ioctl(rawdev->fd,USBDMC_READ_EEPROM,(u_long)arg);
		break;
    case USBDMC_WRITE_EEPROM:
		res = ioctl(rawdev->fd,USBDMC_WRITE_EEPROM,(u_long)arg);
		break;
    case USBDMC_READ_STAT:
		res = ioctl(rawdev->fd,USBDMC_READ_STAT,(u_long)arg);
		break;
    default:
		return(-ENOIOCTLCMD);
    }
#if 0
	printk(KERN_INFO  "tpdmc_ioctl cmd=%d res=%d\n",cmd,res);
#endif
    switch(cmd)
	{
    case USBDMC_READ_EEPROM:
    case USBDMC_WRITE_EEPROM:
		break;
	default:
		if( res < 0 )
			tpcdmc_rawdevclose();
		break;
	}
	return(res);
}
/************************************************************************
 * interface structure
 */
#if KER26
static struct file_operations ops = {
	.open    = tpdmc_open,
	.ioctl   = tpdmc_ioctl,
	.read    = tpdmc_read,
	.poll    = tpdmc_poll,
	.release = tpdmc_close
};
#else
static struct file_operations ops = {
	open    : tpdmc_open,
	ioctl   : tpdmc_ioctl,
	read    : tpdmc_read,
	poll    : tpdmc_poll,
	release : tpdmc_close,
};
#endif

#ifdef MODULE
/************************************************************************
 * tpdmc_term
 */
static void tpdmc_term(void)
{
#if defined(DEBUG_FUNC_ENTRY)
	printk("tpdmc_term entry\n");
#endif
	unregister_chrdev(tpdmc_major,DEVICE_NAME);
	kfree(rawdev);
	printk("tpdmc_term/success\n");
}
/************************************************************************
 * tpdmc_init
 */
static int tpdmc_init(void)
{
int err;
#if defined(DEBUG_FUNC_ENTRY)
	printk("tpdmc_init entry\n");
#endif
	err = register_chrdev(tpdmc_major, DEVICE_NAME, &ops);
	if(err != 0)
	{
		printk("tpdmc_init/register_chrawdev error\n");
		return(-ENODEV);
	}
    if( (rawdev = kmalloc(sizeof(tpdmcrec), GFP_KERNEL)) == NULL )
	{
        printk(KERN_ERR "tpdmc_init/no memory\n");
        return 0;
    }
	rawdev->is_open = 0;
	rawdev->fd = NULL;
	printk("DMC Touch Panel Filter Driver Version %s Major=%d\n"
				,tpdmc_version,tpdmc_major);
	return 0;
}
module_init(tpdmc_init)
module_exit(tpdmc_term)
MODULE_DESCRIPTION("DMC Touch Panel Filter Driver");
MODULE_AUTHOR("DMC");

#endif

